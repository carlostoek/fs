# Investigación: Sistema de Automatización de Desarrollo de Software con Agentes de IA en Termux

## Índice
1. [Resumen Ejecutivo](#resumen-ejecutivo)
2. [Fundamentos de Agentes de IA para Desarrollo de Software](#fundamentos)
3. [Arquitectura de Sistemas Auto-Evolutivos](#arquitectura-auto-evolutiva)
4. [Herramientas y Frameworks Compatibles con Termux](#herramientas-termux)
5. [Diseño del Sistema Propuesto](#diseno-sistema)
6. [Implementación Paso a Paso](#implementacion)
7. [Flujos de Trabajo y Técnicas](#flujos-trabajo)
8. [Memoria y Persistencia](#memoria-persistencia)
9. [Consideraciones de Seguridad](#seguridad)
10. [Recursos y Referencias](#recursos)

---

## Resumen Ejecutivo

Este documento presenta una investigación exhaustiva sobre la automatización del desarrollo de software mediante agentes de inteligencia artificial, con un enfoque específico en la implementación dentro de **Termux** bajo Android. El objetivo principal es diseñar un sistema que no solo automatice tareas de codificación, sino que sea capaz de **evolucionar por sí mismo**, aprendiendo de experiencias previas, evitando repetir errores y mejorando continuamente su rendimiento.

### Objetivos del Sistema
- **Auto-evolución**: El sistema debe mejorar con el tiempo basándose en experiencias previas
- **Memoria persistente**: Mantener conocimiento sobre lo que se ha hecho, bugs encontrados, soluciones aplicadas
- **Estructuración inteligente de prompts**: Un agente principal que optimice y estructure prompts para otros agentes
- **Depuración autónoma**: Capacidad de detectar, analizar y corregir errores de forma autónoma
- **Compatibilidad total con Termux**: Todas las herramientas deben funcionar en Android/Termux

---

## Fundamentos de Agentes de IA para Desarrollo de Software

### 2.1 ¿Qué es un Agente de IA?

Un agente de IA es un sistema de software autónomo que:
- **Percibe** su entorno (código, archivos, APIs)
- **Razona** sobre el estado actual y los objetivos
- **Planifica** secuencias de acciones para alcanzar metas
- **Actúa** ejecutando código, modificando archivos, llamando herramientas
- **Aprende** de los resultados de sus acciones

### 2.2 Tipos de Agentes para Desarrollo de Software

#### Agentes de Codificación (Coding Agents)
- **Función**: Generar, modificar y refactorizar código
- **Ejemplos**: GitHub Copilot, Cursor, Claude Code, Cline
- **Capacidades**: Autocompletado, generación de funciones, refactorización multi-archivo

#### Agentes de Planificación (Planning Agents)
- **Función**: Descomponer tareas complejas en subtareas manejables
- **Ejemplos**: BabyAGI, AutoGPT (modo planificación)
- **Capacidades**: Creación de roadmaps, estimación de esfuerzo, priorización

#### Agentes de Depuración (Debugging Agents)
- **Función**: Detectar, diagnosticar y corregir errores
- **Capacidades**: Análisis de logs, tracing, generación de casos de prueba

#### Agentes de Revisión (Review Agents)
- **Función**: Revisar código, detectar problemas, sugerir mejoras
- **Capacidades**: Análisis estático, revisión de estilo, detección de vulnerabilidades

### 2.3 Paradigmas de Agentes

#### Patrón ReAct (Reasoning + Acting)
El patrón ReAct combina razonamiento verbal con acciones específicas:

```
Thought: Necesito encontrar el precio actual de la acción
Action: get_stock_price
Action Input: AAPL
Observation: 175.50

Thought: Ahora debo calcular el 15% de este valor
Action: calculator
Action Input: 175.50 * 0.15
Observation: 26.325

Final Answer: El 15% del precio de AAPL es $26.33
```

**Ventajas**:
- Transparencia en el proceso de pensamiento
- Capacidad de corrección en tiempo real
- Mejor rendimiento en tareas complejas

#### Patrón Reflexión (Self-Reflection)
Los agentes evalúan y mejoran sus propias salidas:

```
1. Generar respuesta inicial
2. Reflexionar sobre la respuesta (¿Es correcta? ¿Hay errores?)
3. Identificar problemas y oportunidades de mejora
4. Refinar la respuesta basándose en la reflexión
5. Repetir el ciclo si es necesario
```

**Beneficios**:
- Mayor precisión
- Reducción de alucinaciones
- Mejora continua

---

## Arquitectura de Sistemas Auto-Evolutivos

### 3.1 Principios Fundamentales

#### 3.1.1 Meta-Razonamiento
El sistema debe tener una capa de "pensamiento sobre el pensamiento" que:
- Evalúe la efectividad de diferentes estrategias
- Decida cuándo cambiar de enfoque
- Aprenda de los éxitos y fracasos

#### 3.1.2 Memoria Jerárquica
```
Memoria de Trabajo (Working Memory)
├── Contexto de la conversación actual
├── Estado de las tareas en progreso
└── Variables temporales

Memoria a Corto Plazo (Short-term Memory)
├── Sesiones recientes
├── Decisiones tomadas
└── Resultados de tareas recientes

Memoria a Largo Plazo (Long-term Memory)
├── Patrones de éxito
├── Bugs recurrentes y soluciones
├── Preferencias del usuario
└── Conocimiento acumulado del proyecto

Memoria Semántica (Semantic Memory)
├── Conceptos y abstracciones
├── Relaciones entre conceptos
└── Principios generales
```

#### 3.1.3 Aprendizaje Continuo

**Aprendizaje a Corto Plazo**: Adaptación dentro de una sesión
- Ajuste de estrategias basado en feedback inmediato
- Corrección de errores en tiempo real

**Aprendizaje a Mediano Plazo**: Mejora durante semanas/meses
- Identificación de patrones de éxito
- Optimización de prompts basada en resultados

**Aprendizaje a Largo Plazo**: Evolución arquitectónica
- Reestructuración de componentes del sistema
- Adición de nuevas capacidades

### 3.2 Componentes de un Sistema Auto-Evolutivo

#### 3.2.1 Agente Orquestador (Meta-Agent)
Responsabilidades:
- Recibir tareas de alto nivel del usuario
- Descomponer tareas en subtareas específicas
- Asignar subtareas a agentes especializados
- Coordinar la comunicación entre agentes
- Evaluar resultados y tomar decisiones de alto nivel
- Actualizar la memoria del sistema

#### 3.2.2 Agentes Especializados

**Agente de Análisis**:
- Analiza requisitos y especificaciones
- Investiga el código existente
- Identifica dependencias y restricciones

**Agente de Diseño**:
- Crea arquitecturas y diseños
- Define interfaces y contratos
- Documenta decisiones de diseño

**Agente de Implementación**:
- Escribe código siguiendo especificaciones
- Refactoriza código existente
- Implementa tests

**Agente de Depuración**:
- Ejecuta tests y analiza fallos
- Investiga causas raíz de bugs
- Propone y aplica correcciones

**Agente de Verificación**:
- Revisa código generado
- Verifica cumplimiento de requisitos
- Valida calidad y estilo

#### 3.2.3 Sistema de Memoria

**Memoria Episódica**: Registros detallados de interacciones
```python
{
  "session_id": "uuid",
  "timestamp": "2025-01-15T10:30:00Z",
  "task": "Implementar función de autenticación",
  "approach": "Usar JWT con bcrypt",
  "outcome": "success",
  "duration": 1200,
  "bugs_found": 2,
  "bugs_fixed": 2,
  "lessons_learned": ["Validar email antes de hash"]
}
```

**Memoria Semántica**: Conocimiento abstracto extraído
```python
{
  "concept": "autenticación_segura",
  "patterns": ["bcrypt + JWT", "rate limiting", "validación de entrada"],
  "common_pitfalls": ["timing attacks", "weak entropy"],
  "success_rate": 0.95
}
```

**Memoria Procedural**: Estrategias y procedimientos aprendidos
```python
{
  "procedure": "debug_async_code",
  "steps": ["añadir logs", "verificar await", "revisar event loop"],
  "effectiveness": 0.88,
  "usage_count": 45
}
```

### 3.3 Mecanismos de Evolución

#### 3.3.1 Optimización de Prompts
El sistema debe:
- Registrar qué prompts producen mejores resultados
- A/B test diferentes formulaciones
- Ajustar prompts basándose en feedback
- Mantener una librería de prompts optimizados

#### 3.3.2 Selección de Estrategias
```python
# Ejemplo de selección adaptativa
def select_strategy(task_type, context):
    strategies = memory.get_strategies_for(task_type)
    
    # Puntuar cada estrategia
    for strategy in strategies:
        score = (
            strategy.success_rate * 0.4 +
            strategy.relevance_to(context) * 0.3 +
            strategy.recency * 0.2 +
            strategy.efficiency * 0.1
        )
        strategy.score = score
    
    # Seleccionar la mejor
    return max(strategies, key=lambda s: s.score)
```

#### 3.3.3 Consolidación de Memoria
Proceso periódico que:
- Resume episodios antiguos en conocimiento semántico
- Identifica patrones recurrentes
- Elimina información obsoleta
- Refuerza conocimiento importante

---

## Herramientas y Frameworks Compatibles con Termux

### 4.1 Requisitos de Termux

Termux es un emulador de terminal y entorno Linux para Android. Para que las herramientas funcionen en Termux deben:
- Estar escritas en Python puro o tener soporte ARM64
- No depender de binarios específicos de x86/x64
- No requerir Docker o virtualización
- Tener dependencias mínimas o instalables vía pip/pkg

### 4.2 Frameworks de Agentes Ligeros

#### 4.2.1 LightAgent
**Descripción**: Framework ultra-ligero de 1000 líneas de código Python puro

**Características**:
- Sin dependencias de LangChain o LlamaIndex
- Soporte para memoria a largo plazo (mem0)
- Tree of Thought (ToT) integrado
- Multi-agente colaborativo (LightSwarm)
- Generación automática de herramientas
- Soporte para múltiples LLMs (OpenAI, DeepSeek, Qwen)

**Instalación en Termux**:
```bash
pkg install python git
pip install lightagent mem0ai
```

**Uso básico**:
```python
from LightAgent import LightAgent

agent = LightAgent(
    model="gpt-4o-mini",
    api_key="tu_api_key",
    base_url="url_opcional"
)

response = agent.run("Escribe una función Python para calcular fibonacci")
```

#### 4.2.2 PipClaw / MMClaw
**Descripción**: Kernel de agentes autónomos 100% Python puro

**Características**:
- Sin extensiones C, sin Node.js, sin Docker
- Código legible y educativo
- Multiplataforma (Windows, macOS, Linux, Raspberry Pi, Termux)
- Soporte para Telegram y WhatsApp

**Instalación**:
```bash
pip install pipclaw
pipclaw run
```

#### 4.2.3 Kite Agent
**Descripción**: Framework Python para agentes de producción

**Características**:
- Enfoque en seguridad mediante código (no solo prompts)
- Validación de acciones antes de ejecución
- Circuit breakers para prevenir bucles infinitos
- Auditoría completa de decisiones

**Instalación**:
```bash
pip install kite-agent
```

**Ejemplo**:
```python
import asyncio
from kite import Kite

async def main():
    ai = Kite()
    
    def refund_order(order_id: str):
        print(f"Refunding {order_id}...")
        return "Refunded"
    
    refund_tool = ai.create_tool(name="refund", func=refund_order)
    ai.circuit_breaker.config.failure_threshold = 3
    
    agent = ai.create_agent(
        name="SupportBot",
        tools=[refund_tool],
        system_prompt="You are a support agent."
    )
    
    result = await agent.run("Please refund order #999")
    print(result['response'])

asyncio.run(main())
```

#### 4.2.4 Lightweight Agent
**Descripción**: Framework ligero con soporte async

**Características**:
- Soporte async para OpenAI y Anthropic
- Agentes ReAct y TODO-based
- Herramientas integradas (operaciones de archivos, ejecución Python)
- Streaming de respuestas

**Instalación**:
```bash
pip install lightweight-agent
```

### 4.3 Modelos de Lenguaje Locales (LLMs)

#### 4.3.1 llama-cpp-python
**Descripción**: Bindings de Python para llama.cpp

**Instalación en Termux**:
```bash
pkg install clang cmake git
pip install llama-cpp-python --no-cache-dir
```

**Uso como servidor OpenAI-compatible**:
```bash
# Descargar un modelo GGUF primero
python -m llama_cpp.server --model modelo.gguf --chat_format chatml
```

**Modelos recomendados para Termux**:
- `Qwen2.5-Coder-1.5B-Instruct-Q4_K_M.gguf` (rápido, bueno para código)
- `DeepSeek-Coder-V2-Lite-Instruct-Q4_K_M.gguf` (especializado en código)
- `Phi-3-mini-4k-instruct-Q4_K_M.gguf` (muy ligero)

#### 4.3.2 Ollama (vía Termux con proot)
**Nota**: Ollama requiere proot-distro en Termux

```bash
pkg install proot-distro
proot-distro install ubuntu
proot-distro login ubuntu
# Dentro de Ubuntu
apt update && apt install curl
curl -fsSL https://ollama.com/install.sh | sh
ollama pull codellama:7b
```

### 4.4 Bases de Datos Vectoriales y Memoria

#### 4.4.1 SQLite con Extensiones Vectoriales
**Descripción**: SQLite con soporte para embeddings

**Instalación**:
```bash
pip install sqlite-vec
```

**Uso para memoria de agentes**:
```python
import sqlite_vec
import sqlite3

db = sqlite3.connect("agent_memory.db")
db.enable_load_extension(True)
sqlite_vec.load(db)

# Crear tabla vectorial
db.execute("""
    CREATE VIRTUAL TABLE memories USING vec0(
        content TEXT,
        embedding FLOAT[384]
    )
""")
```

#### 4.4.2 sqlite-memory
**Descripción**: Extensión SQLite para memoria de agentes con búsqueda semántica

**Características**:
- Búsqueda híbrida (vectorial + FTS5)
- Chunking consciente de markdown
- Sincronización offline-first entre agentes
- Embeddings locales vía llama.cpp

**Instalación**:
```bash
pip install sqlite-memory
```

### 4.5 Herramientas de Desarrollo

#### 4.5.1 GitPython
**Descripción**: Biblioteca Python para interactuar con repositorios Git

**Instalación**:
```bash
pip install gitpython
```

**Uso para automatización**:
```python
from git import Repo

repo = Repo('.')

# Crear commit automático
repo.index.add(['file.py'])
repo.index.commit("Auto-commit by AI agent")

# Ver diff
for diff in repo.index.diff(None):
    print(diff.change_type, diff.a_path)
```

#### 4.5.2 Tree-sitter
**Descripción**: Parser de código para análisis sintáctico

**Instalación**:
```bash
pip install tree-sitter tree-sitter-python
```

**Uso**:
```python
from tree_sitter import Language, Parser

# Analizar código fuente
code = b"def hello(): pass"
tree = parser.parse(code)
```

### 4.6 Modelos de Embeddings Locales

#### 4.6.1 sentence-transformers (modelos ligeros)
**Modelos recomendados para Termux**:
- `all-MiniLM-L6-v2` (22MB, muy rápido)
- `paraphrase-MiniLM-L3-v2` (13MB, ultra-ligero)
- `multi-qa-MiniLM-L6-cos-v1` (optimizado para Q&A)

**Instalación**:
```bash
pip install sentence-transformers
```

**Uso**:
```python
from sentence_transformers import SentenceTransformer

model = SentenceTransformer('all-MiniLM-L6-v2')
embeddings = model.encode(["texto para embed"])
```

---

## Diseño del Sistema Propuesto

### 5.1 Arquitectura General

```
┌─────────────────────────────────────────────────────────────┐
│                    SISTEMA EVOLUTIVO                        │
│                    "CodeEvolve Agent"                       │
└─────────────────────────────────────────────────────────────┘
                            │
        ┌───────────────────┼───────────────────┐
        ▼                   ▼                   ▼
┌───────────────┐   ┌───────────────┐   ┌───────────────┐
│   Meta-Agent  │   │   Memoria     │   │   Evolución   │
│  Orquestador  │   │  Persistente  │   │   Continua    │
└───────┬───────┘   └───────────────┘   └───────────────┘
        │
   ┌────┴────┬────────┬────────┬────────┐
   ▼         ▼        ▼        ▼        ▼
┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐
│Análisis│ │Diseño │ │Código │ │Debug │ │Review│
└──────┘ └──────┘ └──────┘ └──────┘ └──────┘
```

### 5.2 Componentes Detallados

#### 5.2.1 Meta-Agent Orquestador

**Responsabilidades**:
1. Interfaz principal con el usuario
2. Análisis de requisitos de alto nivel
3. Descomposición de tareas
4. Asignación dinámica de agentes
5. Coordinación de flujo de trabajo
6. Integración de resultados
7. Actualización de memoria

**Prompt del Sistema**:
```
Eres el Orquestador Principal de un sistema de desarrollo de software auto-evolutivo.

TU ROL:
- Recibir tareas de desarrollo de alto nivel
- Analizar y descomponer tareas en subtareas específicas
- Seleccionar el agente especializado apropiado para cada subtarea
- Coordinar la ejecución secuencial o paralela de subtareas
- Integrar los resultados en una solución coherente
- Aprender de cada interacción para mejorar futuras decisiones

CAPACIDADES DISPONIBLES:
- AgenteAnalisis: Investiga código existente, identifica dependencias
- AgenteDiseño: Crea arquitecturas y diseños de soluciones
- AgenteCodigo: Implementa funcionalidades siguiendo especificaciones
- AgenteDebug: Detecta y corrige errores
- AgenteReview: Revisa calidad y verifica requisitos

PROCESO DE TRABAJO:
1. Analizar la solicitud del usuario
2. Consultar la memoria del sistema para contexto relevante
3. Planificar el enfoque óptimo basado en experiencias previas
4. Delegar subtareas a agentes especializados
5. Revisar y validar resultados
6. Actualizar la memoria con aprendizajes
7. Entregar la solución final

REGLAS:
- SIEMPRE consulta la memoria antes de comenzar una tarea similar
- Documenta TODAS las decisiones y su justificación
- Si encuentras un bug, registra: causa, solución, prevención
- Optimiza los prompts basándote en resultados previos
- Mantén un registro de la efectividad de cada estrategia
```

#### 5.2.2 Sistema de Memoria

**Estructura de la Base de Datos**:
```sql
-- Memoria episódica (sesiones y tareas)
CREATE TABLE episodes (
    id INTEGER PRIMARY KEY,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    task_type TEXT,
    description TEXT,
    approach TEXT,
    outcome TEXT,  -- success, failure, partial
    duration_seconds INTEGER,
    agent_used TEXT,
    error_message TEXT,
    solution_applied TEXT
);

-- Memoria semántica (conocimiento extraído)
CREATE TABLE semantic_memory (
    id INTEGER PRIMARY KEY,
    concept TEXT UNIQUE,
    category TEXT,
    patterns TEXT,  -- JSON array
    pitfalls TEXT,  -- JSON array
    best_practices TEXT,  -- JSON array
    success_rate REAL,
    usage_count INTEGER DEFAULT 0
);

-- Memoria de prompts optimizados
CREATE TABLE optimized_prompts (
    id INTEGER PRIMARY KEY,
    task_type TEXT,
    original_prompt TEXT,
    optimized_prompt TEXT,
    success_rate REAL,
    usage_count INTEGER DEFAULT 0,
    avg_tokens_saved INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Bugs y soluciones
CREATE TABLE bug_knowledge (
    id INTEGER PRIMARY KEY,
    error_pattern TEXT,
    context TEXT,
    root_cause TEXT,
    solution TEXT,
    prevention TEXT,
    occurrence_count INTEGER DEFAULT 1,
    first_seen DATETIME,
    last_seen DATETIME
);

-- Métricas de agentes
CREATE TABLE agent_metrics (
    id INTEGER PRIMARY KEY,
    agent_name TEXT,
    task_type TEXT,
    tasks_completed INTEGER DEFAULT 0,
    tasks_failed INTEGER DEFAULT 0,
    avg_duration_seconds REAL,
    avg_tokens_used REAL,
    user_rating REAL,
    last_updated DATETIME
);
```

**API de Memoria**:
```python
class AgentMemory:
    def __init__(self, db_path="agent_memory.db"):
        self.db = sqlite3.connect(db_path)
        self._init_tables()
    
    def store_episode(self, episode: Episode):
        """Almacena una nueva experiencia"""
        pass
    
    def retrieve_similar_episodes(self, task_type, context, limit=5):
        """Recupera experiencias similares"""
        pass
    
    def get_optimized_prompt(self, task_type, context):
        """Obtiene el prompt optimizado para una tarea"""
        pass
    
    def update_prompt_effectiveness(self, prompt_id, success, tokens_used):
        """Actualiza métricas de efectividad de prompts"""
        pass
    
    def find_bug_solution(self, error_message, context):
        """Busca soluciones conocidas para errores"""
        pass
    
    def consolidate_memories(self):
        """Proceso periódico de consolidación"""
        pass
```

#### 5.2.3 Agente de Análisis

**Prompt del Sistema**:
```
Eres el Agente de Análisis. Tu trabajo es investigar y comprender a fondo antes de que se escriba cualquier código.

RESPONSABILIDADES:
1. Analizar requisitos y identificar ambigüedades
2. Investigar el código existente relevante
3. Identificar dependencias y restricciones
4. Proponer enfoques alternativos con pros/contras
5. Documentar hallazgos para otros agentes

PROCESO:
1. Leer archivos relevantes del proyecto
2. Identificar patrones existentes
3. Buscar código similar en la memoria
4. Analizar dependencias
5. Generar un informe de análisis

FORMATO DE SALIDA:
```
## Análisis de Tarea

### Requisitos Identificados
- Req 1
- Req 2

### Código Existente Relevante
- Archivo: líneas X-Y (descripción)

### Dependencias
- Dependencia 1: uso actual

### Enfoques Propuestos
1. **Enfoque A**: descripción, pros, contras
2. **Enfoque B**: descripción, pros, contras

### Recomendación
Recomendación con justificación

### Consideraciones
- Lista de consideraciones importantes
```
```

#### 5.2.4 Agente de Código

**Prompt del Sistema**:
```
Eres el Agente de Implementación. Escribes código de alta calidad siguiendo especificaciones precisas.

PRINCIPIOS:
- Escribe código limpio, legible y bien documentado
- Sigue los patrones del proyecto existente
- Incluye manejo de errores apropiado
- Escribe tests cuando sea apropiado
- NUNCA introduzcas vulnerabilidades de seguridad

ANTES DE ESCRIBIR:
1. Revisa el análisis proporcionado
2. Consulta la memoria para patrones similares
3. Identifica el estilo del proyecto
4. Planifica la estructura del código

FORMATO DE SALIDA:
```
## Implementación

### Archivos Modificados/Creados
- archivo.py: descripción de cambios

### Código
```python
# Código completo aquí
```

### Tests
```python
# Tests incluidos
```

### Notas
- Decisiones importantes
- Dependencias añadidas
```
```

#### 5.2.5 Agente de Depuración

**Prompt del Sistema**:
```
Eres el Agente de Depuración. Encuentras y corriges errores de manera sistemática.

METODOLOGÍA:
1. Reproducir el error consistentemente
2. Aislar el código problemático
3. Identificar la causa raíz
4. Desarrollar y aplicar la solución
5. Verificar la corrección
6. Documentar el aprendizaje

HERRAMIENTAS DISPONIBLES:
- Análisis de logs
- Ejecución de tests
- Inspección de variables
- Revisión de stack traces

FORMATO DE SALIDA:
```
## Informe de Depuración

### Error
Descripción del error

### Reproducción
Pasos para reproducir

### Causa Raíz
Explicación detallada

### Solución
Código de la corrección

### Prevención
Cómo evitar este tipo de errores

### Tests Añadidos
Tests para prevenir regresiones
```
```

### 5.3 Flujo de Trabajo del Sistema

```
Usuario
  │
  ▼
┌─────────────────────────────────────────┐
│ 1. Orquestador recibe tarea            │
│ 2. Consulta memoria para contexto      │
│ 3. Selecciona estrategia óptima        │
└─────────────────────────────────────────┘
  │
  ▼
┌─────────────────────────────────────────┐
│ 4. Delega a Agente de Análisis         │
│    - Investiga código existente        │
│    - Identifica dependencias           │
│    - Propone enfoques                  │
└─────────────────────────────────────────┘
  │
  ▼
┌─────────────────────────────────────────┐
│ 5. Orquestador revisa análisis         │
│ 6. Delega a Agente de Diseño (si aplica)│
└─────────────────────────────────────────┘
  │
  ▼
┌─────────────────────────────────────────┐
│ 7. Delega a Agente de Código           │
│    - Implementa solución               │
│    - Escribe tests                     │
│    - Documenta cambios                 │
└─────────────────────────────────────────┘
  │
  ▼
┌─────────────────────────────────────────┐
│ 8. Ejecuta tests                       │
│    ├─ Éxito → Continúa                 │
│    └─ Fallo → Delega a Agente Debug    │
└─────────────────────────────────────────┘
  │
  ▼
┌─────────────────────────────────────────┐
│ 9. Agente de Review verifica calidad   │
│    - Cumplimiento de requisitos        │
│    - Calidad de código                 │
│    - Posibles mejoras                  │
└─────────────────────────────────────────┘
  │
  ▼
┌─────────────────────────────────────────┐
│ 10. Orquestador integra resultados     │
│ 11. Actualiza memoria con aprendizajes │
│ 12. Entrega solución al usuario        │
└─────────────────────────────────────────┘
```

---

## Implementación Paso a Paso

### 6.1 Instalación del Entorno en Termux

```bash
# 1. Actualizar Termux
pkg update && pkg upgrade

# 2. Instalar dependencias esenciales
pkg install python git clang cmake rust

# 3. Instalar dependencias de Python
pip install --upgrade pip

# 4. Crear entorno virtual (recomendado)
python -m venv ~/agent_env
source ~/agent_env/bin/activate

# 5. Instalar frameworks de agentes
pip install lightagent lightweight-agent kite-agent

# 6. Instalar herramientas de desarrollo
pip install gitpython tree-sitter tree-sitter-python

# 7. Instalar base de datos vectorial
pip install sqlite-vec sentence-transformers

# 8. Instalar llama-cpp-python (opcional, para LLMs locales)
CMAKE_ARGS="-DCMAKE_SYSTEM_NAME=Linux" pip install llama-cpp-python

# 9. Crear directorio del proyecto
mkdir -p ~/CodeEvolveAgent/{agents,memory,tools,config,logs}
cd ~/CodeEvolveAgent
```

### 6.2 Estructura del Proyecto

```
CodeEvolveAgent/
├── config/
│   ├── system_prompts.yaml    # Prompts de cada agente
│   ├── models.yaml            # Configuración de LLMs
│   └── settings.yaml          # Configuración general
├── agents/
│   ├── __init__.py
│   ├── orchestrator.py        # Meta-agent orquestador
│   ├── analyst.py             # Agente de análisis
│   ├── designer.py            # Agente de diseño
│   ├── coder.py               # Agente de implementación
│   ├── debugger.py            # Agente de depuración
│   └── reviewer.py            # Agente de revisión
├── memory/
│   ├── __init__.py
│   ├── database.py            # Gestión de SQLite
│   ├── retrieval.py           # Recuperación de contexto
│   └── consolidation.py       # Consolidación de memoria
├── tools/
│   ├── __init__.py
│   ├── file_operations.py     # Operaciones de archivos
│   ├── code_analysis.py       # Análisis de código
│   ├── git_tools.py           # Operaciones Git
│   └── execution.py           # Ejecución segura
├── core/
│   ├── __init__.py
│   ├── workflow.py            # Gestión de flujos
│   ├── communication.py       # Comunicación entre agentes
│   └── evolution.py           # Mecanismos de evolución
├── logs/
│   └── .gitkeep
├── main.py                    # Punto de entrada
├── setup.py                   # Script de instalación
└── requirements.txt           # Dependencias
```

### 6.3 Implementación del Sistema de Memoria

```python
# memory/database.py
import sqlite3
import json
from datetime import datetime
from typing import List, Dict, Optional
from dataclasses import dataclass

@dataclass
class Episode:
    task_type: str
    description: str
    approach: str
    outcome: str
    duration_seconds: int
    agent_used: str
    error_message: Optional[str] = None
    solution_applied: Optional[str] = None
    context: Optional[Dict] = None

class AgentMemory:
    def __init__(self, db_path="memory/agent_memory.db"):
        self.db_path = db_path
        self.db = sqlite3.connect(db_path, check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self._init_tables()
    
    def _init_tables(self):
        """Inicializa todas las tablas de la base de datos"""
        cursor = self.db.cursor()
        
        # Tabla de episodios
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS episodes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                task_type TEXT NOT NULL,
                description TEXT NOT NULL,
                approach TEXT,
                outcome TEXT NOT NULL,
                duration_seconds INTEGER,
                agent_used TEXT,
                error_message TEXT,
                solution_applied TEXT,
                context TEXT
            )
        """)
        
        # Tabla de memoria semántica
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS semantic_memory (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                concept TEXT UNIQUE NOT NULL,
                category TEXT,
                patterns TEXT,
                pitfalls TEXT,
                best_practices TEXT,
                success_rate REAL DEFAULT 0.0,
                usage_count INTEGER DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Tabla de prompts optimizados
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS optimized_prompts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task_type TEXT NOT NULL,
                context_hash TEXT,
                original_prompt TEXT,
                optimized_prompt TEXT NOT NULL,
                success_rate REAL DEFAULT 0.0,
                usage_count INTEGER DEFAULT 0,
                avg_tokens_saved INTEGER DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(task_type, context_hash)
            )
        """)
        
        # Tabla de conocimiento de bugs
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS bug_knowledge (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                error_pattern TEXT NOT NULL,
                context TEXT,
                root_cause TEXT,
                solution TEXT NOT NULL,
                prevention TEXT,
                occurrence_count INTEGER DEFAULT 1,
                first_seen DATETIME DEFAULT CURRENT_TIMESTAMP,
                last_seen DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Tabla de métricas de agentes
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS agent_metrics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                agent_name TEXT NOT NULL,
                task_type TEXT,
                tasks_completed INTEGER DEFAULT 0,
                tasks_failed INTEGER DEFAULT 0,
                avg_duration_seconds REAL DEFAULT 0.0,
                avg_tokens_used REAL DEFAULT 0.0,
                user_rating REAL DEFAULT 0.0,
                last_updated DATETIME DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(agent_name, task_type)
            )
        """)
        
        self.db.commit()
    
    def store_episode(self, episode: Episode) -> int:
        """Almacena una nueva experiencia/episodio"""
        cursor = self.db.cursor()
        cursor.execute("""
            INSERT INTO episodes 
            (task_type, description, approach, outcome, duration_seconds, 
             agent_used, error_message, solution_applied, context)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            episode.task_type,
            episode.description,
            episode.approach,
            episode.outcome,
            episode.duration_seconds,
            episode.agent_used,
            episode.error_message,
            episode.solution_applied,
            json.dumps(episode.context) if episode.context else None
        ))
        self.db.commit()
        return cursor.lastrowid
    
    def retrieve_similar_episodes(self, task_type: str, limit: int = 5) -> List[Dict]:
        """Recupera episodios similares del mismo tipo de tarea"""
        cursor = self.db.cursor()
        cursor.execute("""
            SELECT * FROM episodes 
            WHERE task_type = ?
            ORDER BY timestamp DESC
            LIMIT ?
        """, (task_type, limit))
        
        episodes = []
        for row in cursor.fetchall():
            episode = dict(row)
            if episode['context']:
                episode['context'] = json.loads(episode['context'])
            episodes.append(episode)
        
        return episodes
    
    def get_successful_approaches(self, task_type: str, limit: int = 3) -> List[Dict]:
        """Obtiene los enfoques más exitosos para un tipo de tarea"""
        cursor = self.db.cursor()
        cursor.execute("""
            SELECT approach, COUNT(*) as count, 
                   AVG(CASE WHEN outcome = 'success' THEN 1 ELSE 0 END) as success_rate
            FROM episodes
            WHERE task_type = ? AND approach IS NOT NULL
            GROUP BY approach
            HAVING count >= 2
            ORDER BY success_rate DESC, count DESC
            LIMIT ?
        """, (task_type, limit))
        
        return [dict(row) for row in cursor.fetchall()]
    
    def store_bug_solution(self, error_pattern: str, solution: str, 
                          context: str = None, root_cause: str = None,
                          prevention: str = None):
        """Almacena una solución para un error conocido"""
        cursor = self.db.cursor()
        
        # Verificar si ya existe
        cursor.execute("""
            SELECT id, occurrence_count FROM bug_knowledge
            WHERE error_pattern = ? AND context = ?
        """, (error_pattern, context))
        
        row = cursor.fetchone()
        if row:
            # Actualizar existente
            cursor.execute("""
                UPDATE bug_knowledge
                SET occurrence_count = occurrence_count + 1,
                    last_seen = CURRENT_TIMESTAMP
                WHERE id = ?
            """, (row['id'],))
        else:
            # Crear nuevo
            cursor.execute("""
                INSERT INTO bug_knowledge
                (error_pattern, context, root_cause, solution, prevention)
                VALUES (?, ?, ?, ?, ?)
            """, (error_pattern, context, root_cause, solution, prevention))
        
        self.db.commit()
    
    def find_bug_solution(self, error_message: str, context: str = None) -> Optional[Dict]:
        """Busca soluciones para un error dado"""
        cursor = self.db.cursor()
        
        # Búsqueda por coincidencia de patrón
        cursor.execute("""
            SELECT * FROM bug_knowledge
            WHERE ? LIKE '%' || error_pattern || '%'
            ORDER BY occurrence_count DESC, last_seen DESC
            LIMIT 1
        """, (error_message,))
        
        row = cursor.fetchone()
        if row:
            return dict(row)
        
        # Si no hay coincidencia exacta, buscar por contexto
        if context:
            cursor.execute("""
                SELECT * FROM bug_knowledge
                WHERE context = ?
                ORDER BY occurrence_count DESC
                LIMIT 1
            """, (context,))
            row = cursor.fetchone()
            if row:
                return dict(row)
        
        return None
    
    def get_optimized_prompt(self, task_type: str, context: str = None) -> Optional[str]:
        """Obtiene el prompt optimizado para una tarea"""
        cursor = self.db.cursor()
        
        # Calcular hash simple del contexto
        context_hash = str(hash(context)) if context else ""
        
        cursor.execute("""
            SELECT optimized_prompt, success_rate
            FROM optimized_prompts
            WHERE task_type = ? AND context_hash = ?
            ORDER BY success_rate DESC, usage_count DESC
            LIMIT 1
        """, (task_type, context_hash))
        
        row = cursor.fetchone()
        if row:
            # Incrementar contador de uso
            cursor.execute("""
                UPDATE optimized_prompts
                SET usage_count = usage_count + 1
                WHERE task_type = ? AND context_hash = ?
            """, (task_type, context_hash))
            self.db.commit()
            return row['optimized_prompt']
        
        return None
    
    def update_agent_metrics(self, agent_name: str, task_type: str, 
                            success: bool, duration: int, tokens_used: int = 0):
        """Actualiza las métricas de un agente"""
        cursor = self.db.cursor()
        
        cursor.execute("""
            INSERT INTO agent_metrics (agent_name, task_type, tasks_completed, tasks_failed,
                                     avg_duration_seconds, avg_tokens_used)
            VALUES (?, ?, ?, ?, ?, ?)
            ON CONFLICT(agent_name, task_type) DO UPDATE SET
                tasks_completed = tasks_completed + ?,
                tasks_failed = tasks_failed + ?,
                avg_duration_seconds = (avg_duration_seconds * (tasks_completed + tasks_failed) + ?) / 
                                      (tasks_completed + tasks_failed + 1),
                avg_tokens_used = (avg_tokens_used * (tasks_completed + tasks_failed) + ?) / 
                                 (tasks_completed + tasks_failed + 1),
                last_updated = CURRENT_TIMESTAMP
        """, (agent_name, task_type, 
              1 if success else 0, 0 if success else 1,
              duration, tokens_used,
              1 if success else 0, 0 if success else 1,
              duration, tokens_used))
        
        self.db.commit()
    
    def get_agent_performance(self, agent_name: str = None) -> List[Dict]:
        """Obtiene métricas de rendimiento de agentes"""
        cursor = self.db.cursor()
        
        if agent_name:
            cursor.execute("""
                SELECT * FROM agent_metrics
                WHERE agent_name = ?
                ORDER BY tasks_completed DESC
            """, (agent_name,))
        else:
            cursor.execute("""
                SELECT agent_name, 
                       SUM(tasks_completed) as total_completed,
                       SUM(tasks_failed) as total_failed,
                       AVG(avg_duration_seconds) as avg_duration
                FROM agent_metrics
                GROUP BY agent_name
                ORDER BY total_completed DESC
            """)
        
        return [dict(row) for row in cursor.fetchall()]
    
    def consolidate_memories(self):
        """Proceso de consolidación de memoria periódico"""
        cursor = self.db.cursor()
        
        # Extraer patrones de episodios exitosos
        cursor.execute("""
            SELECT task_type, approach, COUNT(*) as count,
                   AVG(CASE WHEN outcome = 'success' THEN 1 ELSE 0 END) as success_rate
            FROM episodes
            WHERE timestamp > datetime('now', '-30 days')
            GROUP BY task_type, approach
            HAVING count >= 3
        """)
        
        for row in cursor.fetchall():
            if row['success_rate'] > 0.7:
                # Almacenar como conocimiento semántico
                self._store_semantic_pattern(
                    row['task_type'], 
                    row['approach'],
                    row['success_rate']
                )
        
        # Limpiar episodios antiguos (más de 90 días)
        cursor.execute("""
            DELETE FROM episodes
            WHERE timestamp < datetime('now', '-90 days')
        """)
        
        self.db.commit()
    
    def _store_semantic_pattern(self, task_type: str, pattern: str, success_rate: float):
        """Almacena un patrón en memoria semántica"""
        cursor = self.db.cursor()
        
        cursor.execute("""
            INSERT INTO semantic_memory (concept, category, patterns, success_rate)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(concept) DO UPDATE SET
                patterns = ?,
                success_rate = (success_rate + ?) / 2,
                usage_count = usage_count + 1,
                updated_at = CURRENT_TIMESTAMP
        """, (f"{task_type}_pattern", task_type, json.dumps([pattern]), 
              success_rate, json.dumps([pattern]), success_rate))
        
        self.db.commit()
    
    def close(self):
        """Cierra la conexión a la base de datos"""
        self.db.close()
```

### 6.4 Implementación del Orquestador

```python
# agents/orchestrator.py
import time
import json
from typing import Dict, List, Optional, Callable
from dataclasses import dataclass
from enum import Enum

class TaskStatus(Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    NEEDS_REVIEW = "needs_review"

@dataclass
class Task:
    id: str
    description: str
    task_type: str
    status: TaskStatus
    assigned_agent: Optional[str] = None
    result: Optional[str] = None
    error: Optional[str] = None
    subtasks: List['Task'] = None
    context: Dict = None
    created_at: float = None
    completed_at: float = None

class OrchestratorAgent:
    def __init__(self, memory, llm_client, agents_config: Dict):
        self.memory = memory
        self.llm = llm_client
        self.agents = {}
        self.agents_config = agents_config
        self.active_tasks = {}
        self.workflow_history = []
        
    def register_agent(self, name: str, agent_instance):
        """Registra un agente especializado"""
        self.agents[name] = agent_instance
    
    def process_request(self, user_request: str, context: Dict = None) -> Dict:
        """Procesa una solicitud del usuario"""
        start_time = time.time()
        
        # 1. Crear tarea principal
        task = Task(
            id=f"task_{int(start_time)}",
            description=user_request,
            task_type=self._classify_task(user_request),
            status=TaskStatus.IN_PROGRESS,
            context=context or {},
            created_at=start_time
        )
        
        self.active_tasks[task.id] = task
        
        try:
            # 2. Consultar memoria para contexto relevante
            relevant_memories = self._retrieve_context(task)
            
            # 3. Seleccionar estrategia óptima
            strategy = self._select_strategy(task, relevant_memories)
            
            # 4. Descomponer en subtareas
            subtasks = self._decompose_task(task, strategy)
            task.subtasks = subtasks
            
            # 5. Ejecutar subtareas
            results = []
            for subtask in subtasks:
                result = self._execute_subtask(subtask)
                results.append(result)
                
                if result['status'] == 'failed':
                    # Intentar recuperación
                    recovery_result = self._attempt_recovery(subtask, result)
                    if recovery_result:
                        results[-1] = recovery_result
                    else:
                        raise Exception(f"Subtask failed: {subtask.description}")
            
            # 6. Integrar resultados
            final_result = self._integrate_results(task, results)
            
            # 7. Actualizar memoria
            self._update_memory(task, final_result, time.time() - start_time)
            
            task.status = TaskStatus.COMPLETED
            task.result = final_result
            task.completed_at = time.time()
            
            return {
                'success': True,
                'task_id': task.id,
                'result': final_result,
                'duration': time.time() - start_time,
                'subtasks_completed': len(subtasks)
            }
            
        except Exception as e:
            task.status = TaskStatus.FAILED
            task.error = str(e)
            
            # Registrar fallo en memoria
            self._update_memory(task, None, time.time() - start_time, error=str(e))
            
            return {
                'success': False,
                'task_id': task.id,
                'error': str(e),
                'duration': time.time() - start_time
            }
    
    def _classify_task(self, request: str) -> str:
        """Clasifica el tipo de tarea"""
        # Usar LLM para clasificación
        classification_prompt = f"""
        Clasifica la siguiente solicitud de desarrollo de software en una de estas categorías:
        - feature_implementation
        - bug_fix
        - refactoring
        - code_review
        - testing
        - documentation
        - architecture_design
        - optimization
        
        Solicitud: {request}
        
        Responde solo con la categoría, sin explicación.
        """
        
        response = self.llm.complete(classification_prompt)
        return response.strip().lower()
    
    def _retrieve_context(self, task: Task) -> Dict:
        """Recupera contexto relevante de la memoria"""
        context = {
            'similar_episodes': [],
            'successful_approaches': [],
            'bug_solutions': [],
            'optimized_prompt': None
        }
        
        # Recuperar episodios similares
        context['similar_episodes'] = self.memory.retrieve_similar_episodes(
            task.task_type, limit=5
        )
        
        # Obtener enfoques exitosos
        context['successful_approaches'] = self.memory.get_successful_approaches(
            task.task_type, limit=3
        )
        
        # Buscar prompt optimizado
        context['optimized_prompt'] = self.memory.get_optimized_prompt(
            task.task_type, task.description
        )
        
        return context
    
    def _select_strategy(self, task: Task, context: Dict) -> Dict:
        """Selecciona la estrategia óptima basada en contexto"""
        # Si hay enfoques exitosos previos, usarlos
        if context['successful_approaches']:
            best_approach = context['successful_approaches'][0]
            return {
                'type': 'proven_approach',
                'approach': best_approach['approach'],
                'expected_success_rate': best_approach['success_rate']
            }
        
        # Si no, usar análisis del LLM
        strategy_prompt = f"""
        Dada la siguiente tarea de desarrollo, propón una estrategia de implementación:
        
        Tarea: {task.description}
        Tipo: {task.task_type}
        
        Proporciona:
        1. Enfoque recomendado
        2. Pasos principales
        3. Agentes necesarios
        4. Consideraciones importantes
        
        Responde en formato JSON.
        """
        
        response = self.llm.complete(strategy_prompt)
        try:
            return json.loads(response)
        except:
            return {
                'type': 'standard',
                'approach': 'sequential',
                'agents': ['analyst', 'coder', 'reviewer']
            }
    
    def _decompose_task(self, task: Task, strategy: Dict) -> List[Task]:
        """Descompone una tarea en subtareas"""
        subtasks = []
        
        # Basado en la estrategia, crear subtareas
        if 'agents' in strategy:
            agent_sequence = strategy['agents']
        else:
            agent_sequence = ['analyst', 'coder', 'reviewer']
        
        for i, agent_name in enumerate(agent_sequence):
            subtask = Task(
                id=f"{task.id}_sub_{i}",
                description=f"{agent_name}: {task.description}",
                task_type=f"{task.task_type}_{agent_name}",
                status=TaskStatus.PENDING,
                assigned_agent=agent_name,
                context=task.context
            )
            subtasks.append(subtask)
        
        return subtasks
    
    def _execute_subtask(self, subtask: Task) -> Dict:
        """Ejecuta una subtarea usando el agente asignado"""
        agent_name = subtask.assigned_agent
        
        if agent_name not in self.agents:
            return {
                'status': 'failed',
                'error': f"Agent {agent_name} not found"
            }
        
        agent = self.agents[agent_name]
        subtask.status = TaskStatus.IN_PROGRESS
        
        try:
            # Ejecutar el agente
            result = agent.execute(subtask.description, subtask.context)
            
            subtask.status = TaskStatus.COMPLETED
            subtask.result = result
            
            return {
                'status': 'completed',
                'result': result,
                'agent': agent_name
            }
            
        except Exception as e:
            subtask.status = TaskStatus.FAILED
            subtask.error = str(e)
            
            return {
                'status': 'failed',
                'error': str(e),
                'agent': agent_name
            }
    
    def _attempt_recovery(self, subtask: Task, error_result: Dict) -> Optional[Dict]:
        """Intenta recuperarse de un fallo en subtarea"""
        # Buscar solución en memoria
        bug_solution = self.memory.find_bug_solution(
            error_result.get('error', ''),
            subtask.task_type
        )
        
        if bug_solution:
            # Aplicar solución conocida
            recovery_prompt = f"""
            Se encontró un error conocido. Aplica la siguiente solución:
            
            Error: {error_result.get('error')}
            Causa raíz: {bug_solution.get('root_cause')}
            Solución: {bug_solution.get('solution')}
            
            Contexto de la tarea: {subtask.description}
            """
            
            try:
                result = self.llm.complete(recovery_prompt)
                return {
                    'status': 'completed',
                    'result': result,
                    'agent': 'recovery',
                    'recovery_method': 'known_solution'
                }
            except:
                pass
        
        # Si no hay solución conocida, intentar con agente de debug
        if 'debugger' in self.agents:
            try:
                debug_result = self.agents['debugger'].debug(
                    subtask.description,
                    error_result.get('error')
                )
                return {
                    'status': 'completed',
                    'result': debug_result,
                    'agent': 'debugger',
                    'recovery_method': 'debug_agent'
                }
            except:
                pass
        
        return None
    
    def _integrate_results(self, task: Task, results: List[Dict]) -> str:
        """Integra los resultados de subtareas"""
        integration_prompt = f"""
        Integra los siguientes resultados de subtareas en una solución coherente:
        
        Tarea original: {task.description}
        
        Resultados de subtareas:
        """
        
        for i, result in enumerate(results):
            integration_prompt += f"\n{i+1}. {result.get('agent', 'unknown')}: {result.get('result', 'N/A')[:500]}"
        
        integration_prompt += "\n\nProporciona una respuesta final integrada y coherente."
        
        return self.llm.complete(integration_prompt)
    
    def _update_memory(self, task: Task, result: Optional[str], 
                      duration: float, error: str = None):
        """Actualiza la memoria con el aprendizaje de la tarea"""
        episode = Episode(
            task_type=task.task_type,
            description=task.description,
            approach=json.dumps([s.assigned_agent for s in task.subtasks]) if task.subtasks else "unknown",
            outcome='success' if result else 'failure',
            duration_seconds=int(duration),
            agent_used='orchestrator',
            error_message=error,
            solution_applied=result[:1000] if result else None,
            context=task.context
        )
        
        self.memory.store_episode(episode)
        
        # Actualizar métricas de agentes
        if task.subtasks:
            for subtask in task.subtasks:
                self.memory.update_agent_metrics(
                    subtask.assigned_agent,
                    subtask.task_type,
                    subtask.status == TaskStatus.COMPLETED,
                    int(duration / len(task.subtasks)),
                    0  # tokens usados (obtener de LLM)
                )
```

### 6.5 Implementación de Agentes Especializados

```python
# agents/coder.py
import os
import re
from typing import Dict, List

class CoderAgent:
    """Agente especializado en escritura de código"""
    
    def __init__(self, llm_client, memory):
        self.llm = llm_client
        self.memory = memory
        self.system_prompt = """Eres un agente de implementación de código experto.

PRINCIPIOS:
- Escribe código limpio, legible y bien documentado
- Sigue siempre los patrones del proyecto existente
- Incluye manejo de errores robusto
- Escribe tests unitarios cuando sea apropiado
- Prioriza la seguridad y el rendimiento
- Usa nombres descriptivos para variables y funciones

ANTES DE ESCRIBIR CÓDIGO:
1. Analiza el contexto y requisitos
2. Revisa el código existente relacionado
3. Identifica el estilo y patrones del proyecto
4. Planifica la estructura antes de implementar

FORMATO DE RESPUESTA:
Proporciona el código en bloques markdown con el nombre del archivo.
Incluye una breve explicación de los cambios importantes.
"""
    
    def execute(self, task_description: str, context: Dict = None) -> str:
        """Ejecuta una tarea de codificación"""
        context = context or {}
        
        # Construir prompt completo
        prompt = self._build_prompt(task_description, context)
        
        # Generar código
        response = self.llm.complete(prompt, system_prompt=self.system_prompt)
        
        # Extraer y validar código
        code_blocks = self._extract_code_blocks(response)
        
        # Validar sintaxis básica
        validated_code = self._validate_code(code_blocks)
        
        return validated_code
    
    def _build_prompt(self, task: str, context: Dict) -> str:
        """Construye el prompt para la tarea"""
        prompt = f"Tarea: {task}\n\n"
        
        # Añadir contexto del proyecto
        if 'project_files' in context:
            prompt += "Archivos relevantes del proyecto:\n"
            for file_path, content in context['project_files'].items():
                prompt += f"\n--- {file_path} ---\n{content[:1000]}\n"
        
        # Añadir estilo del proyecto
        if 'coding_style' in context:
            prompt += f"\nEstilo de código del proyecto:\n{context['coding_style']}\n"
        
        # Añadir requisitos específicos
        if 'requirements' in context:
            prompt += f"\nRequisitos específicos:\n{context['requirements']}\n"
        
        prompt += "\nProporciona el código completo implementando la tarea."
        
        return prompt
    
    def _extract_code_blocks(self, response: str) -> List[Dict]:
        """Extrae bloques de código de la respuesta"""
        code_blocks = []
        
        # Patrón para bloques de código markdown
        pattern = r'```(\w+)?\n(.*?)```'
        matches = re.findall(pattern, response, re.DOTALL)
        
        for lang, code in matches:
            code_blocks.append({
                'language': lang or 'text',
                'code': code.strip()
            })
        
        return code_blocks
    
    def _validate_code(self, code_blocks: List[Dict]) -> str:
        """Valida la sintaxis básica del código"""
        validated = []
        
        for block in code_blocks:
            if block['language'] == 'python':
                try:
                    compile(block['code'], '<string>', 'exec')
                    validated.append(block)
                except SyntaxError as e:
                    validated.append({
                        'language': 'python',
                        'code': f"# Error de sintaxis: {e}\n{block['code']}"
                    })
            else:
                validated.append(block)
        
        # Formatear resultado
        result = ""
        for block in validated:
            result += f"```{block['language']}\n{block['code']}\n```\n\n"
        
        return result
    
    def refactor(self, file_path: str, refactoring_goal: str) -> str:
        """Refactoriza código existente"""
        # Leer archivo
        with open(file_path, 'r') as f:
            original_code = f.read()
        
        prompt = f"""
        Refactoriza el siguiente código:
        
        Objetivo: {refactoring_goal}
        
        Código original:
        ```python
        {original_code}
        ```
        
        Proporciona el código refactorizado manteniendo la funcionalidad.
        Explica los cambios principales realizados.
        """
        
        return self.llm.complete(prompt, system_prompt=self.system_prompt)
    
    def add_tests(self, code: str, test_framework: str = 'pytest') -> str:
        """Genera tests para el código proporcionado"""
        prompt = f"""
        Genera tests {test_framework} para el siguiente código:
        
        ```python
        {code}
        ```
        
        Incluye:
        - Tests para casos normales
        - Tests para edge cases
        - Tests para manejo de errores
        
        Proporciona solo el código de los tests.
        """
        
        return self.llm.complete(prompt, system_prompt=self.system_prompt)


# agents/debugger.py
import re
from typing import Dict, Optional

class DebuggerAgent:
    """Agente especializado en depuración"""
    
    def __init__(self, llm_client, memory):
        self.llm = llm_client
        self.memory = memory
        self.system_prompt = """Eres un agente de depuración experto.

METODOLOGÍA DE DEPURACIÓN:
1. Reproduce el error consistentemente
2. Aísla el código problemático
3. Identifica la causa raíz
4. Desarrolla y aplica la solución
5. Verifica la corrección
6. Documenta el aprendizaje

HERRAMIENTAS DE ANÁLISIS:
- Análisis de stack traces
- Revisión de logs
- Inspección de variables
- Ejecución paso a paso
- Análisis de flujo de datos

PRINCIPIOS:
- Nunca asumas, verifica con evidencia
- Considera múltiples hipótesis
- Prueba una solución a la vez
- Documenta todo el proceso
"""
    
    def debug(self, task_description: str, error_message: str, 
              context: Dict = None) -> str:
        """Depura un error dado"""
        context = context or {}
        
        # Buscar solución conocida primero
        known_solution = self.memory.find_bug_solution(error_message)
        if known_solution:
            return self._apply_known_solution(known_solution, task_description)
        
        # Proceder con depuración sistemática
        prompt = self._build_debug_prompt(task_description, error_message, context)
        
        return self.llm.complete(prompt, system_prompt=self.system_prompt)
    
    def _build_debug_prompt(self, task: str, error: str, context: Dict) -> str:
        """Construye el prompt de depuración"""
        prompt = f"""Depura el siguiente error:

Tarea: {task}
Error: {error}
"""
        
        if 'code' in context:
            prompt += f"\nCódigo relevante:\n```python\n{context['code']}\n```\n"
        
        if 'logs' in context:
            prompt += f"\nLogs:\n{context['logs']}\n"
        
        if 'stack_trace' in context:
            prompt += f"\nStack trace:\n{context['stack_trace']}\n"
        
        prompt += """
        Proporciona:
        1. Análisis del error
        2. Causa raíz identificada
        3. Solución propuesta (con código)
        4. Prevención para el futuro
        """
        
        return prompt
    
    def _apply_known_solution(self, solution: Dict, task: str) -> str:
        """Aplica una solución conocida de la memoria"""
        prompt = f"""
        Se encontró un error similar previamente resuelto:
        
        Causa raíz conocida: {solution.get('root_cause')}
        Solución: {solution.get('solution')}
        Prevención: {solution.get('prevention')}
        
        Aplica esta solución al contexto actual:
        {task}
        
        Adapta la solución si es necesario y proporciona el código corregido.
        """
        
        return self.llm.complete(prompt, system_prompt=self.system_prompt)
    
    def analyze_stack_trace(self, stack_trace: str) -> Dict:
        """Analiza un stack trace para extraer información útil"""
        analysis = {
            'error_type': None,
            'error_message': None,
            'file_locations': [],
            'line_numbers': []
        }
        
        # Extraer tipo de error
        error_match = re.search(r'(\w+Error):\s*(.+)', stack_trace)
        if error_match:
            analysis['error_type'] = error_match.group(1)
            analysis['error_message'] = error_match.group(2)
        
        # Extraer ubicaciones de archivos
        file_pattern = r'File "([^"]+)", line (\d+)'
        matches = re.findall(file_pattern, stack_trace)
        analysis['file_locations'] = [m[0] for m in matches]
        analysis['line_numbers'] = [int(m[1]) for m in matches]
        
        return analysis
```

### 6.6 Script Principal

```python
# main.py
#!/usr/bin/env python3
"""
CodeEvolve Agent - Sistema de Desarrollo Auto-Evolutivo
Compatible con Termux/Android
"""

import os
import sys
import argparse
from pathlib import Path

# Añadir directorio al path
sys.path.insert(0, str(Path(__file__).parent))

from memory.database import AgentMemory
from agents.orchestrator import OrchestratorAgent
from agents.coder import CoderAgent
from agents.debugger import DebuggerAgent

class SimpleLLMClient:
    """Cliente LLM simple usando requests (compatible con múltiples proveedores)"""
    
    def __init__(self, api_key=None, base_url=None, model="gpt-4o-mini"):
        self.api_key = api_key or os.getenv('OPENAI_API_KEY')
        self.base_url = base_url or "https://api.openai.com/v1"
        self.model = model
        
        try:
            import openai
            self.client = openai.OpenAI(api_key=self.api_key, base_url=self.base_url)
        except ImportError:
            print("Instalando openai...")
            os.system("pip install openai")
            import openai
            self.client = openai.OpenAI(api_key=self.api_key, base_url=self.base_url)
    
    def complete(self, prompt, system_prompt=None, temperature=0.7):
        """Completa un prompt"""
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})
        
        response = self.client.chat.completions.create(
            model=self.model,
            messages=messages,
            temperature=temperature
        )
        
        return response.choices[0].message.content


def setup_environment():
    """Configura el entorno inicial"""
    # Crear directorios necesarios
    dirs = ['memory', 'logs', 'config', 'tools']
    for d in dirs:
        Path(d).mkdir(exist_ok=True)
    
    # Verificar API key
    if not os.getenv('OPENAI_API_KEY'):
        print("⚠️  Advertencia: OPENAI_API_KEY no está configurada")
        print("Configúrala con: export OPENAI_API_KEY='tu-api-key'")
        return False
    
    return True


def interactive_mode(orchestrator):
    """Modo interactivo del sistema"""
    print("\n" + "="*60)
    print("🤖 CodeEvolve Agent - Modo Interactivo")
    print("="*60)
    print("\nComandos disponibles:")
    print("  /help     - Mostrar ayuda")
    print("  /status   - Ver estado del sistema")
    print("  /memory   - Consultar memoria")
    print("  /agents   - Listar agentes disponibles")
    print("  /quit     - Salir")
    print("\nEscribe tu solicitud de desarrollo o un comando.")
    print("-"*60 + "\n")
    
    while True:
        try:
            user_input = input("\n📝 > ").strip()
            
            if not user_input:
                continue
            
            if user_input.startswith('/'):
                handle_command(user_input, orchestrator)
            else:
                # Procesar solicitud de desarrollo
                print("\n⏳ Procesando solicitud...")
                result = orchestrator.process_request(user_input)
                
                if result['success']:
                    print(f"\n✅ Tarea completada en {result['duration']:.2f}s")
                    print(f"\n📄 Resultado:\n{result['result']}")
                else:
                    print(f"\n❌ Error: {result['error']}")
            
        except KeyboardInterrupt:
            print("\n\n👋 Saliendo...")
            break
        except Exception as e:
            print(f"\n❌ Error: {e}")


def handle_command(cmd, orchestrator):
    """Maneja comandos especiales"""
    if cmd == '/help':
        print("""
Comandos disponibles:
  /help     - Mostrar esta ayuda
  /status   - Ver estado del sistema
  /memory   - Consultar estadísticas de memoria
  /agents   - Listar agentes y su rendimiento
  /quit     - Salir del sistema
        """)
    
    elif cmd == '/status':
        print("\n📊 Estado del Sistema:")
        print(f"  Tareas activas: {len(orchestrator.active_tasks)}")
        print(f"  Agentes registrados: {list(orchestrator.agents.keys())}")
    
    elif cmd == '/memory':
        stats = orchestrator.memory.get_agent_performance()
        print("\n🧠 Estadísticas de Memoria:")
        for stat in stats:
            print(f"  {stat['agent_name']}: {stat.get('total_completed', 0)} tareas")
    
    elif cmd == '/agents':
        print("\n🤖 Agentes Disponibles:")
        for name in orchestrator.agents.keys():
            print(f"  - {name}")
    
    elif cmd == '/quit':
        print("\n👋 Saliendo...")
        sys.exit(0)
    
    else:
        print(f"Comando desconocido: {cmd}")


def main():
    parser = argparse.ArgumentParser(description='CodeEvolve Agent')
    parser.add_argument('--task', '-t', help='Tarea a ejecutar (modo no interactivo)')
    parser.add_argument('--model', '-m', default='gpt-4o-mini', help='Modelo LLM a usar')
    parser.add_argument('--setup', action='store_true', help='Configurar entorno inicial')
    
    args = parser.parse_args()
    
    if args.setup:
        print("🔧 Configurando entorno...")
        setup_environment()
        print("✅ Configuración completada")
        return
    
    # Verificar entorno
    if not setup_environment():
        return
    
    # Inicializar componentes
    print("🚀 Iniciando CodeEvolve Agent...")
    
    # Cliente LLM
    llm = SimpleLLMClient(model=args.model)
    
    # Memoria
    memory = AgentMemory()
    
    # Orquestador
    orchestrator = OrchestratorAgent(memory, llm, {})
    
    # Registrar agentes especializados
    orchestrator.register_agent('coder', CoderAgent(llm, memory))
    orchestrator.register_agent('debugger', DebuggerAgent(llm, memory))
    # Añadir más agentes según sea necesario
    
    print("✅ Sistema iniciado correctamente")
    
    if args.task:
        # Modo no interactivo
        print(f"\n📝 Ejecutando: {args.task}")
        result = orchestrator.process_request(args.task)
        
        if result['success']:
            print(f"\n✅ Completado en {result['duration']:.2f}s")
            print(f"\n{result['result']}")
        else:
            print(f"\n❌ Error: {result['error']}")
    else:
        # Modo interactivo
        interactive_mode(orchestrator)


if __name__ == '__main__':
    main()
```

---

## Flujos de Trabajo y Técnicas

### 7.1 Patrón de Razonamiento: Tree of Thought (ToT)

El Tree of Thought permite explorar múltiples caminos de razonamiento:

```
Problema
    │
    ├─── Enfoque A
    │      ├── Resultado A1
    │      └── Resultado A2
    │
    ├─── Enfoque B
    │      ├── Resultado B1
    │      └── Resultado B2
    │
    └─── Enfoque C
           └── Resultado C1

Evaluación y selección del mejor camino
```

**Implementación**:
```python
class TreeOfThought:
    def solve(self, problem, num_branches=3, depth=2):
        # Generar múltiples enfoques
        approaches = self.generate_approaches(problem, num_branches)
        
        # Explorar cada enfoque
        solutions = []
        for approach in approaches:
            solution = self.explore_path(approach, depth)
            solutions.append(solution)
        
        # Evaluar y seleccionar
        best = self.evaluate_solutions(solutions)
        return best
```

### 7.2 Patrón de Reflexión Iterativa

```python
class ReflexionAgent:
    def execute_with_reflexion(self, task, max_cycles=3):
        output = self.generate_initial(task)
        
        for cycle in range(max_cycles):
            # Reflexionar
            reflection = self.reflect(output, task)
            
            # Evaluar si necesita mejora
            if self.is_satisfactory(reflection):
                break
            
            # Refinar
            output = self.refine(output, reflection)
        
        return output
```

### 7.3 Flujo de Desarrollo Completo

```
1. RECEPCIÓN DE TAREA
   └── Usuario describe la funcionalidad deseada

2. ANÁLISIS Y PLANIFICACIÓN
   ├── Orquestador consulta memoria
   ├── Agente de Análisis investiga código existente
   ├── Se identifican dependencias y patrones
   └── Se genera plan de implementación

3. DISEÑO (si es necesario)
   ├── Agente de Diseño crea arquitectura
   ├── Se definen interfaces
   └── Se documentan decisiones

4. IMPLEMENTACIÓN
   ├── Agente de Código escribe funcionalidad
   ├── Se siguen patrones del proyecto
   └── Se incluye manejo de errores

5. TESTING
   ├── Se ejecutan tests existentes
   ├── Agente de Código genera nuevos tests
   └── Se verifica cobertura

6. REVISIÓN
   ├── Agente de Review verifica calidad
   ├── Se identifican mejoras
   └── Se validan requisitos

7. DEPURACIÓN (si hay errores)
   ├── Agente de Debug analiza fallos
   ├── Se aplica solución
   └── Se actualiza memoria de bugs

8. INTEGRACIÓN
   ├── Orquestador integra cambios
   ├── Se actualiza documentación
   └── Se crea commit

9. APRENDIZAJE
   ├── Se registra episodio en memoria
   ├── Se actualizan métricas
   └── Se consolidan patrones
```

---

## Memoria y Persistencia

### 8.1 Estrategias de Almacenamiento

#### Memoria de Corto Plazo
- **Almacenamiento**: SQLite en memoria o archivo
- **Retención**: Sesión actual + últimas N interacciones
- **Uso**: Contexto inmediato de conversación

#### Memoria de Largo Plazo
- **Almacenamiento**: SQLite persistente
- **Retención**: Permanente
- **Uso**: Conocimiento acumulado, patrones, bugs

#### Memoria Vectorial
- **Almacenamiento**: SQLite con extensión vectorial
- **Embeddings**: Modelos ligeros (MiniLM)
- **Uso**: Búsqueda semántica de código y documentación

### 8.2 Consolidación de Memoria

Proceso periódico que:

1. **Identifica patrones**: Encuentra soluciones recurrentes
2. **Resume episodios**: Convierte experiencias en conocimiento
3. **Actualiza métricas**: Refleja efectividad de estrategias
4. **Elimina obsolescencia**: Limpia información no relevante
5. **Refuerza importante**: Prioriza conocimiento valioso

```python
def consolidate_memories():
    # Ejecutar cada semana o cuando la DB crezca
    
    # 1. Extraer patrones exitosos
    patterns = extract_successful_patterns(last_30_days)
    
    # 2. Actualizar memoria semántica
    for pattern in patterns:
        update_semantic_memory(pattern)
    
    # 3. Limpiar episodios antiguos
    delete_episodes_older_than(90_days)
    
    # 4. Optimizar prompts basados en resultados
    optimize_prompts_based_on_performance()
```

### 8.3 Recuperación de Contexto

```python
def retrieve_context(query, task_type):
    context = {}
    
    # 1. Búsqueda semántica en código
    context['relevant_code'] = vector_search(query, k=5)
    
    # 2. Recuperar episodios similares
    context['similar_tasks'] = get_similar_episodes(task_type, k=3)
    
    # 3. Buscar soluciones a bugs relacionados
    context['bug_solutions'] = search_bug_knowledge(query)
    
    # 4. Obtener prompts optimizados
    context['optimized_prompt'] = get_best_prompt(task_type)
    
    return context
```

---

## Consideraciones de Seguridad

### 9.1 Principios de Seguridad

1. **Principio de Mínimo Privilegio**
   - El agente solo debe tener acceso a lo necesario
   - Usar usuarios y permisos restrictivos
   - Scope de credenciales limitado

2. **Sandboxing**
   - Ejecutar código en entornos aislados
   - Limitar acceso al sistema de archivos
   - Restringir operaciones de red

3. **Validación de Entradas**
   - Tratar todo output de herramientas como no confiable
   - Verificar que acciones trazan al prompt original
   - Sanitizar inputs antes de ejecución

4. **Timeouts y Límites**
   - Límites en tiempo de ejecución
   - Máximo número de iteraciones
   - Restricciones de uso de tokens

### 9.2 Implementación de Seguridad en Termux

```python
import subprocess
import tempfile
import os

class SecureExecution:
    def __init__(self, timeout=30, max_output_size=10000):
        self.timeout = timeout
        self.max_output_size = max_output_size
    
    def execute_code(self, code, language='python'):
        """Ejecuta código de forma segura"""
        
        # Crear archivo temporal
        with tempfile.NamedTemporaryFile(
            mode='w', 
            suffix=f'.{language}',
            delete=False
        ) as f:
            f.write(code)
            temp_file = f.name
        
        try:
            # Ejecutar con timeout
            result = subprocess.run(
                ['python', temp_file],
                capture_output=True,
                text=True,
                timeout=self.timeout
            )
            
            # Limitar tamaño de salida
            stdout = result.stdout[:self.max_output_size]
            stderr = result.stderr[:self.max_output_size]
            
            return {
                'success': result.returncode == 0,
                'stdout': stdout,
                'stderr': stderr,
                'returncode': result.returncode
            }
            
        except subprocess.TimeoutExpired:
            return {
                'success': False,
                'error': f'Execution timed out after {self.timeout}s'
            }
        finally:
            # Limpiar archivo temporal
            os.unlink(temp_file)
```

---

## Recursos y Referencias

### 10.1 Frameworks y Bibliotecas

| Framework | Descripción | Instalación Termux |
|-----------|-------------|-------------------|
| LightAgent | Framework ultra-ligero (1000 líneas) | `pip install lightagent` |
| PipClaw | Kernel 100% Python puro | `pip install pipclaw` |
| Kite Agent | Framework con enfoque en seguridad | `pip install kite-agent` |
| lightweight-agent | Framework async ligero | `pip install lightweight-agent` |
| sqlite-vec | SQLite con vectores | `pip install sqlite-vec` |
| sentence-transformers | Embeddings locales | `pip install sentence-transformers` |
| llama-cpp-python | LLMs locales | `CMAKE_ARGS="..." pip install llama-cpp-python` |
| GitPython | Automatización Git | `pip install gitpython` |

### 10.2 Modelos Recomendados para Termux

| Modelo | Tamaño | Uso | Descarga |
|--------|--------|-----|----------|
| Qwen2.5-Coder-1.5B-Q4 | ~1GB | Codificación rápida | HuggingFace |
| DeepSeek-Coder-V2-Lite-Q4 | ~2GB | Codificación avanzada | HuggingFace |
| Phi-3-mini-4k-Q4 | ~800MB | Tareas generales | HuggingFace |
| CodeLlama-7B-Q4 | ~4GB | Codificación compleja | HuggingFace |
| all-MiniLM-L6-v2 | 22MB | Embeddings | sentence-transformers |

### 10.3 Patrones de Agentes

| Patrón | Descripción | Uso |
|--------|-------------|-----|
| ReAct | Reasoning + Acting | Tareas que requieren herramientas |
| Reflexion | Auto-evaluación | Mejora iterativa de calidad |
| Tree of Thought | Exploración múltiple | Problemas complejos |
| Multi-Agent | Colaboración especializada | Proyectos grandes |
| RAG | Retrieval Augmented Generation | Conocimiento específico |

### 10.4 Referencias Académicas y Técnicas

1. **ReAct Pattern**: Yao et al. - "ReAct: Synergizing Reasoning and Acting in Language Models"
2. **Reflexion**: Shinn et al. - "Reflexion: Self-Reflective Agents"
3. **Tree of Thought**: Yao et al. - "Tree of Thoughts: Deliberate Problem Solving"
4. **Multi-Agent Systems**: Wooldridge - "An Introduction to MultiAgent Systems"
5. **LLM-Based MAS for SE**: arXiv:2404.04834 - "LLM-Based Multi-Agent Systems for Software Engineering"

### 10.5 Comunidades y Recursos

- **GitHub**: github.com/aitools/awesome-ai-agents
- **Reddit**: r/LocalLLaMA, r/ArtificialIntelligence
- **Discord**: LangChain, LlamaIndex, Ollama
- **Documentación**: 
  - docs.llamaindex.ai
  - python.langchain.com
  - docs.crewai.com

---

## Conclusión

Este documento presenta un diseño completo para un sistema de automatización de desarrollo de software con agentes de IA que:

1. **Evoluciona continuamente** aprendiendo de experiencias previas
2. **Mantiene memoria persistente** de bugs, soluciones y patrones
3. **Utiliza múltiples agentes especializados** coordinados por un orquestador
4. **Es completamente compatible con Termux** en Android
5. **Implementa mecanismos de seguridad** para ejecución segura
6. **Optimiza prompts y estrategias** basándose en resultados

El sistema propuesto puede implementarse incrementalmente, comenzando con componentes básicos y expandiendo funcionalidad según sea necesario. La clave del éxito está en:

- **Mantener registros detallados** de todas las interacciones
- **Consolidar periódicamente** el conocimiento adquirido
- **Medir y optimizar** continuamente el rendimiento
- **Iterar y mejorar** los prompts basándose en resultados

Con esta arquitectura, el sistema no solo automatiza tareas de desarrollo, sino que se vuelve más inteligente y efectivo con cada uso, evitando repetir errores y acumulando conocimiento valioso sobre el proyecto y las preferencias del desarrollador.

---

*Documento generado el 2025-01-15*
*Versión 1.0 - Sistema CodeEvolve Agent*
