#!/bin/bash
# Script de Instalación para CodeEvolve Agent en Termux
# Compatible con Android/Termux

set -e

# Colores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

print_banner() {
    echo -e "${BLUE}"
    echo "╔═══════════════════════════════════════════════════════════════╗"
    echo "║                                                               ║"
    echo "║           🚀 CodeEvolve Agent - Instalador Termux            ║"
    echo "║                                                               ║"
    echo "║     Sistema de Desarrollo Auto-Evolutivo con Agentes IA      ║"
    echo "║                                                               ║"
    echo "╚═══════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
}

print_step() {
    echo -e "${BLUE}[PASO $1/$2]${NC} $3"
}

print_success() {
    echo -e "${GREEN}✓${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}⚠${NC} $1"
}

print_error() {
    echo -e "${RED}✗${NC} $1"
}

# Verificar que estamos en Termux
if [ -z "$TERMUX_VERSION" ] && [ -z "$TERMUX_API_VERSION" ]; then
    print_warning "No se detectó Termux. Este script está optimizado para Termux."
    read -p "¿Continuar de todos modos? (y/n): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

TOTAL_STEPS=8
current_step=0

print_banner

# Paso 1: Actualizar paquetes
((current_step++))
print_step $current_step $TOTAL_STEPS "Actualizando paquetes de Termux..."
pkg update -y && pkg upgrade -y
print_success "Paquetes actualizados"

# Paso 2: Instalar dependencias del sistema
((current_step++))
print_step $current_step $TOTAL_STEPS "Instalando dependencias del sistema..."
pkg install -y \
    python \
    git \
    clang \
    cmake \
    rust \
    libffi \
    openssl \
    libxml2 \
    libxslt \
    pkg-config
print_success "Dependencias del sistema instaladas"

# Paso 3: Actualizar pip
((current_step++))
print_step $current_step $TOTAL_STEPS "Actualizando pip..."
pip install --upgrade pip setuptools wheel
print_success "pip actualizado"

# Paso 4: Crear directorio del proyecto
((current_step++))
print_step $current_step $TOTAL_STEPS "Creando estructura del proyecto..."
PROJECT_DIR="$HOME/CodeEvolveAgent"
mkdir -p "$PROJECT_DIR"/{agents,memory,tools,config,logs}
cd "$PROJECT_DIR"
print_success "Directorio del proyecto creado en $PROJECT_DIR"

# Paso 5: Crear entorno virtual (opcional pero recomendado)
((current_step++))
print_step $current_step $TOTAL_STEPS "Configurando entorno virtual..."
python -m venv venv
source venv/bin/activate
print_success "Entorno virtual creado y activado"

# Paso 6: Instalar dependencias de Python
((current_step++))
print_step $current_step $TOTAL_STEPS "Instalando dependencias de Python..."

# Instalar primero las dependencias críticas
pip install --no-cache-dir \
    cython \
    numpy \
    pybind11

# Instalar frameworks de agentes
pip install --no-cache-dir \
    lightagent \
    lightweight-agent

# Instalar clientes LLM
pip install --no-cache-dir \
    openai \
    anthropic

# Instalar herramientas de memoria
pip install --no-cache-dir \
    sqlite-vec \
    sentence-transformers

# Instalar herramientas de desarrollo
pip install --no-cache-dir \
    gitpython \
    tree-sitter \
    tree-sitter-python

# Instalar utilidades
pip install --no-cache-dir \
    pyyaml \
    python-dotenv \
    requests \
    rich

print_success "Dependencias de Python instaladas"

# Paso 7: Crear archivos de configuración
((current_step++))
print_step $current_step $TOTAL_STEPS "Creando archivos de configuración..."

# Crear .env template
cat > "$PROJECT_DIR/.env.template" << 'EOF'
# Configuración de API Keys
# Copia este archivo a .env y configura tus claves

# OpenAI (requerido para usar GPT-4, GPT-3.5)
OPENAI_API_KEY=sk-tu-api-key-aqui

# Anthropic (opcional, para Claude)
ANTHROPIC_API_KEY=sk-ant-tu-api-key-aqui

# Otras configuraciones
DEFAULT_MODEL=gpt-4o-mini
LOG_LEVEL=INFO
MEMORY_DB_PATH=memory/agent_memory.db
EOF

# Crear config.yaml
cat > "$PROJECT_DIR/config/settings.yaml" << 'EOF'
# Configuración de CodeEvolve Agent

system:
  name: "CodeEvolve Agent"
  version: "1.0.0"
  log_level: "INFO"
  log_path: "logs"

memory:
  db_path: "memory/agent_memory.db"
  consolidation_interval_days: 7
  max_episode_age_days: 90

llm:
  default_model: "gpt-4o-mini"
  fallback_model: "gpt-3.5-turbo"
  temperature: 0.7
  max_tokens: 4000
  timeout: 60

agents:
  orchestrator:
    max_subtasks: 10
    enable_recovery: true
  
  coder:
    validate_syntax: true
    auto_format: true
    generate_tests: true
  
  debugger:
    max_debug_cycles: 3
    search_known_solutions: true
  
  reviewer:
    check_style: true
    check_security: true
    check_performance: true

security:
  enable_sandbox: true
  max_execution_time: 30
  max_output_size: 10000
  allowed_file_extensions:
    - ".py"
    - ".js"
    - ".ts"
    - ".html"
    - ".css"
    - ".json"
    - ".yaml"
    - ".md"
EOF

# Crear prompts.yaml
cat > "$PROJECT_DIR/config/system_prompts.yaml" << 'EOF'
# Prompts del Sistema para cada Agente

orchestrator: |
  Eres el Orquestador Principal de un sistema de desarrollo de software auto-evolutivo.
  
  TU ROL:
  - Recibir tareas de desarrollo de alto nivel
  - Analizar y descomponer tareas en subtareas específicas
  - Seleccionar el agente especializado apropiado para cada subtarea
  - Coordinar la ejecución secuencial o paralela de subtareas
  - Integrar los resultados en una solución coherente
  - Aprender de cada interacción para mejorar futuras decisiones
  
  CAPACIDADES DISPONIBLES:
  - AgenteAnalisis: Investiga código existente, identifica dependencias
  - AgenteDiseño: Crea arquitecturas y diseños de soluciones
  - AgenteCodigo: Implementa funcionalidades siguiendo especificaciones
  - AgenteDebug: Detecta y corrige errores
  - AgenteReview: Revisa calidad y verifica requisitos
  
  REGLAS:
  - SIEMPRE consulta la memoria antes de comenzar una tarea similar
  - Documenta TODAS las decisiones y su justificación
  - Si encuentras un bug, registra: causa, solución, prevención
  - Optimiza los prompts basándote en resultados previos

coder: |
  Eres un agente de implementación de código experto.
  
  PRINCIPIOS:
  - Escribe código limpio, legible y bien documentado
  - Sigue siempre los patrones del proyecto existente
  - Incluye manejo de errores robusto
  - Escribe tests unitarios cuando sea apropiado
  - Prioriza la seguridad y el rendimiento
  
  FORMATO DE RESPUESTA:
  Proporciona el código en bloques markdown con el nombre del archivo.
  Incluye una breve explicación de los cambios importantes.

debugger: |
  Eres un agente de depuración experto.
  
  METODOLOGÍA:
  1. Reproduce el error consistentemente
  2. Aísla el código problemático
  3. Identifica la causa raíz
  4. Desarrolla y aplica la solución
  5. Verifica la corrección
  
  PRINCIPIOS:
  - Nunca asumas, verifica con evidencia
  - Considera múltiples hipótesis
  - Documenta todo el proceso

reviewer: |
  Eres un agente de revisión de código experto.
  
  RESPONSABILIDADES:
  - Verificar cumplimiento de requisitos
  - Identificar problemas de calidad
  - Detectar posibles bugs
  - Sugerir mejoras de rendimiento
  - Verificar seguridad del código
  
  FORMATO:
  Proporciona feedback estructurado con severidad (alta/media/baja).
EOF

print_success "Archivos de configuración creados"

# Paso 8: Crear script de inicio
((current_step++))
print_step $current_step $TOTAL_STEPS "Creando script de inicio..."

cat > "$PROJECT_DIR/start.sh" << 'EOF'
#!/bin/bash
# Script de inicio para CodeEvolve Agent

cd "$(dirname "$0")"

# Activar entorno virtual
if [ -d "venv" ]; then
    source venv/bin/activate
fi

# Verificar API key
if [ -z "$OPENAI_API_KEY" ]; then
    if [ -f ".env" ]; then
        export $(cat .env | grep -v '^#' | xargs)
    else
        echo "⚠️  ADVERTENCIA: OPENAI_API_KEY no está configurada"
        echo "Crea un archivo .env con tu API key:"
        echo "  echo 'OPENAI_API_KEY=sk-tu-key' > .env"
        echo ""
        read -p "¿Continuar de todos modos? (y/n): " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            exit 1
        fi
    fi
fi

# Iniciar el sistema
echo "🚀 Iniciando CodeEvolve Agent..."
python main.py "$@"
EOF

chmod +x "$PROJECT_DIR/start.sh"
print_success "Script de inicio creado"

# Crear README
cat > "$PROJECT_DIR/README.md" << 'EOF'
# 🚀 CodeEvolve Agent

Sistema de desarrollo de software auto-evolutivo con agentes de IA.
Compatible con Termux/Android.

## Características

- 🤖 **Múltiples Agentes Especializados**: Análisis, diseño, código, depuración, revisión
- 🧠 **Memoria Persistente**: Aprende de experiencias previas
- 📈 **Auto-Evolución**: Mejora continuamente su rendimiento
- 🔒 **Seguro**: Ejecución sandboxed y validación de código
- 📱 **Compatible con Termux**: Funciona completamente en Android

## Instalación Rápida

```bash
# Ejecutar el instalador
bash install_termux.sh

# Configurar API key
cd CodeEvolveAgent
cp .env.template .env
# Editar .env con tu OPENAI_API_KEY

# Iniciar
./start.sh
```

## Uso

### Modo Interactivo
```bash
./start.sh
```

### Modo Comando
```bash
./start.sh --task "Crear una función para calcular fibonacci"
```

## Estructura del Proyecto

```
CodeEvolveAgent/
├── agents/          # Agentes especializados
├── memory/          # Sistema de memoria
├── tools/           # Herramientas auxiliares
├── config/          # Configuración
├── logs/            # Logs del sistema
├── main.py          # Punto de entrada
└── start.sh         # Script de inicio
```

## Comandos Disponibles

- `/help` - Mostrar ayuda
- `/status` - Ver estado del sistema
- `/memory` - Consultar estadísticas de memoria
- `/agents` - Listar agentes disponibles
- `/quit` - Salir

## Configuración

Edita `config/settings.yaml` para personalizar:
- Modelos LLM
- Límites de seguridad
- Comportamiento de agentes

## Licencia

MIT License
EOF

print_success "README creado"

echo ""
echo -e "${GREEN}╔═══════════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║                    ✅ INSTALACIÓN COMPLETADA                   ║${NC}"
echo -e "${GREEN}╚═══════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${BLUE}Próximos pasos:${NC}"
echo ""
echo "1. Configura tu API key:"
echo -e "   ${YELLOW}cd $PROJECT_DIR${NC}"
echo -e "   ${YELLOW}cp .env.template .env${NC}"
echo -e "   ${YELLOW}nano .env${NC}  # Edita con tu OPENAI_API_KEY"
echo ""
echo "2. Inicia el sistema:"
echo -e "   ${YELLOW}./start.sh${NC}"
echo ""
echo "3. Lee la documentación completa:"
echo -e "   ${YELLOW}cat investigacion_agentes_ia_termux.md${NC}"
echo ""
echo -e "${GREEN}¡Listo para evolucionar tu desarrollo de software! 🚀${NC}"
echo ""
