# 🚀 Guía Rápida - CodeEvolve Agent

## Instalación en 3 Pasos

### Paso 1: Ejecutar el Instalador
```bash
cd /mnt/okcomputer/output
bash install_termux.sh
```

### Paso 2: Configurar API Key
```bash
cd ~/CodeEvolveAgent
cp .env.template .env
nano .env  # Añade tu OPENAI_API_KEY
```

### Paso 3: Iniciar
```bash
./start.sh
```

---

## Uso Básico

### Modo Interactivo (Recomendado)
```bash
./start.sh

# Ejemplos de solicitudes:
> Crea una función para validar emails
> Refactoriza el archivo main.py para usar clases
> Implementa autenticación JWT
> Debug este error: AttributeError: 'NoneType' has no attribute...
```

### Modo Comando Directo
```bash
./start.sh --task "Crear una API REST con Flask"
./start.sh --task "Implementar ordenamiento quicksort" --model gpt-4o
```

---

## Comandos del Sistema

| Comando | Descripción |
|---------|-------------|
| `/help` | Mostrar ayuda |
| `/status` | Estado del sistema |
| `/memory` | Estadísticas de memoria |
| `/agents` | Listar agentes |
| `/quit` | Salir |

---

## Ejemplos de Tareas

### Desarrollo de Funciones
```
> Crea una función Python que calcule el factorial de un número
  con manejo de errores para inputs negativos
```

### Refactorización
```
> Refactoriza este código para usar list comprehensions
  y mejora los nombres de variables
```

### Debugging
```
> Debug: AttributeError: 'dict' object has no attribute 'append'
  en la línea 45 de data_processor.py
```

### Diseño de Arquitectura
```
> Diseña una arquitectura para un sistema de autenticación
  con JWT, refresh tokens y roles de usuario
```

### Testing
```
> Genera tests unitarios para la clase UserManager
  usando pytest con cobertura de edge cases
```

---

## Configuración Avanzada

### Cambiar Modelo LLM
Edita `config/settings.yaml`:
```yaml
llm:
  default_model: "gpt-4o"  # o "gpt-4o-mini", "claude-3-sonnet"
```

### Ajustar Límites de Seguridad
```yaml
security:
  max_execution_time: 60  # segundos
  max_output_size: 20000  # caracteres
```

### Configurar Memoria
```yaml
memory:
  consolidation_interval_days: 7  # Frecuencia de consolidación
  max_episode_age_days: 90        # Retención de episodios
```

---

## Solución de Problemas

### Error: "OPENAI_API_KEY no configurada"
```bash
export OPENAI_API_KEY='sk-tu-api-key'
# O edita el archivo .env
```

### Error: "Module not found"
```bash
source venv/bin/activate
pip install -r requirements.txt
```

### Error de permisos
```bash
chmod +x start.sh install_termux.sh
```

### Memoria llena
```bash
# Limpiar episodios antiguos
rm memory/agent_memory.db
# El sistema creará una nueva base de datos
```

---

## Arquitectura del Sistema

```
Usuario
  │
  ▼
┌─────────────────┐
│  Orquestador    │ ← Coordina todo
│   (Meta-Agent)  │
└────────┬────────┘
         │
    ┌────┴────┬────────┬────────┐
    ▼         ▼        ▼        ▼
┌───────┐ ┌───────┐ ┌───────┐ ┌───────┐
│Análisis│ │ Código │ │ Debug │ │ Review│
└───────┘ └───────┘ └───────┘ └───────┘
    │         │        │        │
    └─────────┴────────┴────────┘
              │
              ▼
        ┌──────────┐
        │  Memoria │ ← Aprendizaje persistente
        │ SQLite   │
        └──────────┘
```

---

## Flujo de Aprendizaje

1. **Ejecución**: El sistema ejecuta una tarea
2. **Registro**: Se guarda el episodio en memoria
3. **Análisis**: Se analizan resultados y errores
4. **Consolidación**: Se extraen patrones semánticos
5. **Optimización**: Se mejoran prompts y estrategias
6. **Reutilización**: Se aplican aprendizajes futuros

---

## Consejos de Uso

### ✅ Mejores Prácticas
- **Sé específico**: Describe claramente lo que necesitas
- **Proporciona contexto**: Menciona archivos relevantes
- **Itera**: Refina la solicitud basándote en resultados
- **Revisa**: Siempre revisa el código generado
- **Feedback**: El sistema aprende de tus correcciones

### ❌ Evitar
- Solicitudes vagas: "Arregla el código"
- Tareas demasiado grandes: Divide en partes
- Ignorar errores: Reporta problemas al sistema
- Desactivar memoria: Pierdes el aprendizaje acumulado

---

## Métricas del Sistema

Consulta el rendimiento:
```bash
./start.sh
> /memory
```

Muestra:
- Tareas completadas por agente
- Tasa de éxito
- Tiempo promedio
- Bugs resueltos

---

## Integración con Proyectos Existentes

Para usar con un proyecto existente:

```bash
# Navegar a tu proyecto
cd ~/mi-proyecto

# Ejecutar CodeEvolve Agent desde allí
~/CodeEvolveAgent/start.sh

# El sistema detectará automáticamente los archivos
```

---

## Actualización

```bash
cd ~/CodeEvolveAgent
source venv/bin/activate

# Actualizar dependencias
pip install --upgrade lightagent lightweight-agent openai

# Actualizar desde repositorio (si aplica)
git pull origin main
```

---

## Recursos Adicionales

- 📖 **Documentación Completa**: `investigacion_agentes_ia_termux.md`
- 🔧 **Configuración**: `config/settings.yaml`
- 📝 **Prompts**: `config/system_prompts.yaml`
- 🐛 **Logs**: `logs/`

---

## Soporte

### Reportar Problemas
1. Revisa los logs: `cat logs/agent.log`
2. Verifica la configuración
3. Consulta la documentación completa

### Comunidad
- GitHub Issues
- Discusiones en el repositorio

---

**¡Tu sistema evoluciona con cada uso!** 🚀

Cuanto más lo uses, más inteligente se vuelve al aprender:
- Tus patrones de código preferidos
- Soluciones a bugs recurrentes
- Estrategias efectivas para tu proyecto
- Optimizaciones específicas de tu stack
