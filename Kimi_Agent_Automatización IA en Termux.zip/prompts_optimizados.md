# 📚 Librería de Prompts Optimizados

Esta librería contiene prompts probados y optimizados para diferentes tipos de tareas de desarrollo de software.

## Índice
1. [Generación de Código](#generación-de-código)
2. [Refactorización](#refactorización)
3. [Debugging](#debugging)
4. [Testing](#testing)
5. [Documentación](#documentación)
6. [Análisis de Código](#análisis-de-código)
7. [Arquitectura](#arquitectura)

---

## Generación de Código

### Función con Manejo de Errores
```
Crea una función Python llamada {nombre_funcion} que:
1. Reciba los parámetros: {parametros}
2. Realice: {descripcion_funcionalidad}
3. Maneje estos errores específicos:
   - {tipo_error_1}: {manejo_1}
   - {tipo_error_2}: {manejo_2}
4. Retorne: {valor_retorno}
5. Incluya docstring con ejemplos de uso
6. Siga PEP 8 y type hints
```

### Clase con Métodos
```
Implementa una clase Python llamada {nombre_clase} que:

ATRIBUTOS:
- {atributo_1}: {tipo} - {descripcion}
- {atributo_2}: {tipo} - {descripcion}

MÉTODOS REQUERIDOS:
1. __init__(self, {params}): Inicialización
2. {metodo_1}({params}): {descripcion}
3. {metodo_2}({params}): {descripcion}

REQUISITOS:
- Usar dataclasses si aplica
- Implementar __repr__ y __str__
- Manejar estados inválidos
- Incluir validaciones
- Documentar con docstrings
```

### API REST Endpoint
```
Crea un endpoint {metodo_http} /{ruta} usando {framework} que:

FUNCIONALIDAD:
{descripcion}

REQUEST:
- Headers requeridos: {headers}
- Body (JSON): {schema_request}
- Query params: {params}

RESPONSE:
- 200: {schema_response_200}
- 400: {schema_response_400}
- 401: {schema_response_401}
- 500: {schema_response_500}

IMPLEMENTACIÓN:
- Validación de inputs
- Autenticación/Autorización
- Manejo de errores
- Logging
- Rate limiting (opcional)
```

---

## Refactorización

### Mejorar Legibilidad
```
Refactoriza el siguiente código para mejorar legibilidad:

CÓDIGO ORIGINAL:
```python
{codigo_original}
```

OBJETIVOS:
1. Renombrar variables con nombres descriptivos
2. Extraer funciones/métodos si hay duplicación
3. Simplificar expresiones complejas
4. Usar list/dict comprehensions donde aplique
5. Reducir anidación (early returns)
6. Añadir type hints
7. Mejorar docstrings

RESTRICCIONES:
- Mantener funcionalidad idéntica
- No cambiar interfaces públicas
- Preservar comportamiento de edge cases
```

### Optimizar Rendimiento
```
Optimiza el siguiente código para mejor rendimiento:

CÓDIGO ORIGINAL:
```python
{codigo_original}
```

OBJETIVOS DE OPTIMIZACIÓN:
1. Complejidad temporal: de {O_actual} a {O_objetivo}
2. Uso de memoria: reducir {aspecto_memoria}
3. Reducir operaciones I/O
4. Minimizar allocations

PERFILADO:
- Input típico: {descripcion_input}
- Cuello de botella actual: {descripcion_cuello}

RESTRICCIONES:
- Mantener corrección
- No usar librerías externas (solo stdlib)
- Documentar trade-offs
```

### Aplicar Patrones de Diseño
```
Refactoriza para aplicar el patrón {nombre_patron}:

CÓDIGO ACTUAL:
```python
{codigo_actual}
```

PATRÓN A APLICAR: {nombre_patron}
MOTIVACIÓN: {por_que_aplicar}

RESULTADO ESPERADO:
- Estructura del patrón
- Beneficios obtenidos
- Cómo extender en el futuro
```

---

## Debugging

### Análisis de Error
```
Analiza y corrige el siguiente error:

ERROR:
```
{mensaje_error}
```

STACK TRACE:
```
{stack_trace}
```

CÓDIGO RELEVANTE:
```python
{codigo_relevante}
```

CONTEXTO:
- Framework: {framework}
- Versión Python: {version}
- Entorno: {entorno}

ENTREGABLES:
1. Causa raíz del error
2. Línea(s) específica(s) problemáticas
3. Código corregido
4. Explicación de la solución
5. Prevención para evitar recurrencia
```

### Debugging de Performance
```
Investiga el problema de rendimiento:

SÍNTOMAS:
- {sintoma_1}
- {sintoma_2}

PERFILADO:
```
{resultados_profiling}
```

CÓDIGO:
```python
{codigo}
```

OBJETIVO:
- Reducir tiempo de ejecución de {tiempo_actual} a {tiempo_objetivo}
- Identificar cuellos de botella
- Proponer optimizaciones
```

---

## Testing

### Tests Unitarios
```
Genera tests unitarios para:

CÓDIGO A TESTEAR:
```python
{codigo}
```

REQUISITOS:
1. Framework: pytest
2. Cobertura: casos normales, edge cases, errores
3. Fixtures para setup complejo
4. Mocks para dependencias externas
5. Parametrización para múltiples casos
6. Nombres descriptivos: test_{funcion}_{escenario}

ESTRUCTURA:
```python
def test_{funcion}_caso_normal():
    # Arrange
    # Act
    # Assert

def test_{funcion}_edge_case():
    # Arrange
    # Act
    # Assert

def test_{funcion}_error_esperado():
    # Arrange
    # Act & Assert
```
```

### Tests de Integración
```
Genera tests de integración para:

COMPONENTES:
- {componente_1}
- {componente_2}

FLUJO A TESTEAR:
{descripcion_flujo}

REQUISITOS:
1. Setup de base de datos/dependencias
2. Test del flujo completo
3. Verificación de estado final
4. Cleanup después de cada test
5. Manejo de transacciones
```

### Tests de Performance
```
Genera benchmarks para:

FUNCIÓN: {nombre_funcion}

REQUISITOS:
1. Usar pytest-benchmark
2. Múltiples tamaños de input
3. Métricas: tiempo, memoria
4. Comparación con baseline
5. Assertions de rendimiento
```

---

## Documentación

### Docstring de Función
```
Genera docstring completo para:

```python
def {nombre_funcion}({params}):
    # TODO: Docstring
    {implementacion}
```

FORMATO: Google Style / NumPy Style
INCLUIR:
- Descripción clara
- Args con tipos y descripciones
- Returns con tipo y descripción
- Raises con condiciones
- Ejemplos de uso
- Notas adicionales
```

### README de Proyecto
```
Genera un README.md para el proyecto:

NOMBRE: {nombre_proyecto}
DESCRIPCIÓN: {descripcion_breve}

SECCIONES REQUERIDAS:
1. Título y badges
2. Descripción corta (1-2 párrafos)
3. Características principales
4. Instalación (pasos claros)
5. Uso básico (ejemplos de código)
6. Documentación (enlace)
7. Contribución (guías)
8. Licencia
9. Autores/Agradecimientos

ESTILO: Profesional, claro, con emojis apropiados
```

### Documentación de API
```
Genera documentación OpenAPI/Swagger para:

ENDPOINTS:
{lista_endpoints}

FORMATO: OpenAPI 3.0
INCLUIR:
- Descripción de cada endpoint
- Schemas de request/response
- Códigos de error
- Ejemplos
- Autenticación requerida
```

---

## Análisis de Código

### Análisis de Seguridad
```
Realiza análisis de seguridad del código:

```python
{codigo}
```

VERIFICAR:
1. Inyección SQL/NoSQL
2. XSS
3. CSRF
4. Exposición de datos sensibles
5. Validación de inputs
6. Autenticación/Autorización
7. Manejo de secrets
8. Dependencias vulnerables

ENTREGABLES:
- Lista de vulnerabilidades (si hay)
- Severidad de cada una
- Código corregido
- Recomendaciones generales
```

### Análisis de Calidad
```
Analiza la calidad del código:

```python
{codigo}
```

CRITERIOS:
1. Complejidad ciclomática
2. Duplicación de código
3. Longitud de funciones
4. Nomenclatura
5. Cobertura de docstrings
6. Type hints
7. Manejo de errores
8. Cohesión y acoplamiento

MÉTRICAS:
- Calcular cuando sea posible
- Comparar con estándares
- Identificar hotspots

RECOMENDACIONES:
- Priorizadas por impacto
- Con ejemplos de refactorización
```

### Análisis de Dependencias
```
Analiza las dependencias del proyecto:

DEPENDENCIAS:
```
{lista_dependencias}
```

ANÁLISIS:
1. Dependencias desactualizadas
2. Vulnerabilidades conocidas
3. Licencias incompatibles
4. Dependencias no usadas
5. Alternativas más ligeras
6. Árbol de dependencias

RECOMENDACIONES:
- Actualizaciones sugeridas
- Reemplazos recomendados
- Eliminaciones seguras
```

---

## Arquitectura

### Diseño de Sistema
```
Diseña la arquitectura para:

REQUISITOS:
- Funcionalidad: {descripcion}
- Escalabilidad: {requisitos_escala}
- Performance: {requisitos_perf}
- Seguridad: {requisitos_seg}

COMPONENTES A DISEÑAR:
1. {componente_1}
2. {componente_2}
3. {componente_3}

ENTREGABLES:
1. Diagrama de arquitectura (descripción)
2. Diagrama de componentes
3. Diagrama de flujo de datos
4. Interfaces entre componentes
5. Stack tecnológico recomendado
6. Consideraciones de deployment
7. Trade-offs documentados
```

### Diseño de Base de Datos
```
Diseña el esquema de base de datos para:

REQUISITOS:
{descripcion_requisitos}

ENTIDADES PRINCIPALES:
- {entidad_1}: {descripcion}
- {entidad_2}: {descripcion}

RESTRICCIONES:
- Normalización: {nivel}
- Índices necesarios: {indices}
- Particionamiento: {si_aplica}

ENTREGABLES:
1. Diagrama ER (descripción)
2. Schema SQL/DDL
3. Índices recomendados
4. Constraints
5. Queries de ejemplo
6. Estrategia de migración
```

### Diseño de API
```
Diseña una API RESTful para:

DOMINIO: {dominio}
RECURSOS:
- {recurso_1}
- {recurso_2}

REQUISITOS:
- Autenticación: {tipo_auth}
- Rate limiting: {limites}
- Versionado: {estrategia}
- Documentación: OpenAPI

ESTÁNDARES:
- RESTful
- JSON:API / HAL (opcional)
- HATEOAS (opcional)

ENTREGABLES:
1. Lista de endpoints
2. Métodos HTTP por endpoint
3. Schemas de request/response
4. Códigos de estado
5. Headers requeridos
6. Ejemplos de uso
```

---

## Prompts para Casos Específicos

### Migración de Código
```
Migra el siguiente código de {lenguaje_origen} a {lenguaje_destino}:

CÓDIGO ORIGINAL:
```
{codigo_original}
```

REQUISITOS:
- Mantener funcionalidad idéntica
- Seguir idiomas del lenguaje destino
- Usar librerías estándar cuando sea posible
- Documentar diferencias importantes
- Incluir tests de equivalencia
```

### Implementación de Algoritmo
```
Implementa el algoritmo {nombre_algoritmo}:

ESPECIFICACIÓN:
- Entrada: {descripcion_input}
- Salida: {descripcion_output}
- Complejidad esperada: {complejidad}

REQUISITOS:
1. Pseudocódigo primero
2. Implementación optimizada
3. Análisis de complejidad
4. Casos de prueba
5. Comparación con alternativas
```

### Configuración de Herramientas
```
Genera configuración para {herramienta}:

REQUISITOS:
- Entorno: {entorno}
- Versión: {version}
- Caso de uso: {caso_uso}

CONFIGURACIONES:
- Desarrollo
- Testing
- Producción

COMENTARIOS:
- Explicar opciones importantes
- Señalar valores a personalizar
- Incluir buenas prácticas
```

---

## Uso de Variables

Los prompts usan variables entre `{}` que deben reemplazarse:

| Variable | Descripción | Ejemplo |
|----------|-------------|---------|
| `{nombre_funcion}` | Nombre de función | `calculate_fibonacci` |
| `{parametros}` | Lista de parámetros | `n: int, memo: dict` |
| `{descripcion}` | Descripción textual | "Calcula el factorial" |
| `{codigo}` | Bloque de código | `def foo(): pass` |
| `{tipo_error}` | Tipo de excepción | `ValueError` |

---

## Tips para Prompts Efectivos

1. **Sé Específico**: Evita términos vagos
2. **Proporciona Contexto**: Menciona el entorno
3. **Define el Formato**: Especifica cómo quieres la salida
4. **Incluye Restricciones**: Limita lo que NO debe hacer
5. **Pide Ejemplos**: Solicita casos de uso
6. **Itera**: Refina basándote en resultados

---

## Personalización

Para adaptar estos prompts a tu proyecto:

1. **Guarda en memoria**: El sistema aprende de tus preferencias
2. **Ajusta estilo**: Modifica para seguir tus convenciones
3. **Añade contexto**: Incluye información de tu stack
4. **Define estándares**: Especifica tus reglas de equipo

---

*Esta librería se expande con cada uso del sistema*
